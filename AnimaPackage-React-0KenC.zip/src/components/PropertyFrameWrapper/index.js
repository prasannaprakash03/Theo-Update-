export { PropertyFrameWrapper } from "./PropertyFrameWrapper";
