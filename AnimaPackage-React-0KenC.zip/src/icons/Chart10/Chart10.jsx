import React from "react";
import styled from "styled-components";

const StyledSvg = styled.svg`
  &.chart-10 {
    fill: none;
    height: 70px;
    width: 115px;
  }
`;

export const Chart10 = ({ className }) => {
  return (
    <StyledSvg
      className={`chart-10 ${className}`}
      viewBox="0 0 115 70"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path-2"
        d="M1.99976 7.16968L4.31903 11.1408C6.63831 15.1119 11.2769 23.0541 15.9154 25.6499C20.554 28.2457 25.1925 25.495 29.8311 28.314C34.4696 31.133 39.1082 39.5216 43.7467 39.6863C48.3853 39.8509 53.0239 31.7917 57.6624 31.3463C62.301 30.9009 66.9395 38.0694 71.5781 40.8075C76.2166 43.5455 80.8552 41.8533 85.4937 42.0955C90.1323 42.3378 94.7708 44.5145 99.4094 49.2785C104.048 54.0425 108.687 61.3938 111.006 65.0694L113.325 68.745"
        stroke="#D82C60"
        strokeLinecap="round"
        strokeWidth="2.40964"
      />
    </StyledSvg>
  );
};
