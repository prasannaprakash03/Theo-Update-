import React from "react";
import styled from "styled-components";

const StyledSvg = styled.svg`
  &.chart-2 {
    fill: none;
    height: 70px;
    width: 115px;
  }

  & .path-2 {
    stroke: #d82c60;
    stroke-linecap: round;
    stroke-width: 2.40964;
  }
`;

export const Chart2 = ({ className }) => {
  return (
    <StyledSvg className={`chart-2 ${className}`} viewBox="0 0 115 70">
      <path
        className="path-2"
        d="M1.79932 45.8389L4.11407 43.999C6.42882 42.159 11.0583 38.4791 15.6878 35.7339C20.3173 32.9887 24.9468 31.1781 29.5763 33.2437C34.2058 35.3092 38.8353 41.2509 43.4648 43.2081C48.0944 45.1654 52.7239 43.1382 57.3534 41.9399C61.9829 40.7416 66.6124 40.3723 71.2419 43.7907C75.8714 47.2092 80.5009 54.4154 85.1304 56.7762C89.7599 59.137 94.3894 56.6524 99.0189 57.8396C103.648 59.0269 108.278 63.886 110.593 66.3155L112.907 68.745"
      />
    </StyledSvg>
  );
};
