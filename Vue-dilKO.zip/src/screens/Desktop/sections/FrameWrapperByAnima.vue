<template>
  <div class="frame-wrapper-by-anima">
    <div class="frame-5">
      <div class="rectangle" />
      <div class="rectangle-2" />
      <div class="card-crypto">
        <PropertyWrapper
          ETHClassName="component-1-instance"
          className="component-1"
          divClassName="design-component-instance-node"
          divClassNameOverride="component-3"
          frameClassName="component-2"
          property1="three"
          tether="/img/tether-1.svg"
          text="U"
          titleClassName="component-instance"
        />
      </div>
      <div class="card-crypto-2">
        <PropertyWrapper
          ETHClassName="component-5"
          className="component-4"
          divClassName="component-6"
          divClassNameOverride="component-3"
          frameClassName="component-7"
          property1="two"
          text1=""
          text2="4"
          titleClassName="component-instance"
          uniswap="/img/uniswap-1.svg"
        />
        <Chart2 class="chart" />
      </div>
      <div class="overlap-group-wrapper">
        <div class="overlap-group-2">
          <div class="group-2">
            <div class="card-crypto-3">
              <PropertyWrapper
                ETHClassName="component-9"
                LUNA="/img/luna-1.svg"
                className="component-8"
                divClassName="component-10"
                divClassNameOverride="component-3"
                frameClassName="component-11"
                property1="four"
                titleClassName="component-instance"
              />
              <Chart1 class="chart-1" />
            </div>
            <div class="card-crypto-4">
              <PropertyWrapper
                ETH="/img/eth-1.svg"
                ETHClassName="component-9"
                className="component-12"
                divClassName="component-13"
                divClassNameOverride="component-3"
                frameClassName="component-11"
                property1="six"
                titleClassName="component-instance"
              />
              <Chart2 class="icon-instance-node" />
            </div>
            <div class="card-crypto-5">
              <PropertyWrapper
                ETHClassName="component-9"
                className="component-14"
                divClassName="component-15"
                divClassNameOverride="component-3"
                doge="/img/doge-1.svg"
                frameClassName="component-11"
                property1="one"
                text2="45%"
                titleClassName="component-instance"
              />
              <Chart9 class="chart-2" />
            </div>
            <div class="card-crypto-6">
              <PropertyWrapper
                ETHClassName="component-9"
                className="component-14"
                divClassName="component-16"
                divClassNameOverride="component-3"
                frameClassName="component-11"
                property1="two"
                text1="UNI/USD"
                text2="45%"
                titleClassName="component-instance"
                uniswap="/img/uniswap-2.svg"
              />
              <Chart2 class="chart-2" />
            </div>
          </div>
          <div class="group-3">
            <div class="card-crypto-7">
              <PropertyWrapper
                ETHClassName="component-9"
                className="component-14"
                divClassName="component-17"
                divClassNameOverride="component-3"
                doge="/img/doge-2.svg"
                frameClassName="component-11"
                property1="one"
                text2="45%"
                titleClassName="component-instance"
              />
              <Chart9 class="chart-2" />
            </div>
            <div class="card-crypto-8">
              <PropertyWrapper
                ETH="/img/eth-2.svg"
                ETHClassName="component-9"
                className="component-18"
                divClassName="component-19"
                divClassNameOverride="component-3"
                frameClassName="component-11"
                property1="six"
                titleClassName="component-instance"
              />
              <Chart2 class="icon-instance-node" />
            </div>
            <div class="card-crypto-9">
              <PropertyWrapper
                ETHClassName="component-9"
                className="component-14"
                divClassName="component-16"
                divClassNameOverride="component-3"
                frameClassName="component-11"
                property1="three"
                tether="/img/tether-2.svg"
                text="USDT/USD"
                titleClassName="component-instance"
              />
              <Chart10 class="chart-2" />
            </div>
            <div class="card-crypto-10">
              <PropertyWrapper
                ETHClassName="component-9"
                LUNA="/img/luna-2.svg"
                className="component-18"
                divClassName="component-19"
                divClassNameOverride="component-3"
                frameClassName="component-11"
                property1="four"
                titleClassName="component-instance"
              />
              <Chart1 class="icon-instance-node" />
            </div>
          </div>
          <div class="group-4">
            <div class="card-crypto-11">
              <PropertyWrapper
                ETHClassName="component-9"
                className="component-14"
                divClassName="component-17"
                divClassNameOverride="component-3"
                doge="/img/doge-3.svg"
                frameClassName="component-11"
                property1="one"
                text2="45%"
                titleClassName="component-instance"
              />
              <Chart9 class="chart-2" />
            </div>
            <div class="card-crypto-12">
              <PropertyWrapper
                ETHClassName="component-9"
                className="component-18"
                divClassName="component-16"
                divClassNameOverride="component-3"
                frameClassName="component-11"
                property1="three"
                tether="/img/tether-3.svg"
                text="USDT/USD"
                titleClassName="component-instance"
              />
              <Chart10 class="icon-instance-node" />
            </div>
            <div class="card-crypto-13">
              <PropertyWrapper
                ETHClassName="component-9"
                className="component-14"
                divClassName="component-19"
                divClassNameOverride="component-3"
                frameClassName="component-11"
                property1="five"
                solana="/img/solana-1.svg"
                titleClassName="component-instance"
              />
              <Chart11 class="chart-2" />
            </div>
            <div class="card-crypto-14">
              <PropertyWrapper
                ETHClassName="component-9"
                LUNA="/img/luna-3.svg"
                className="component-14"
                divClassName="component-19"
                divClassNameOverride="component-3"
                frameClassName="component-11"
                property1="four"
                titleClassName="component-instance"
              />
              <Chart1 class="chart-2" />
            </div>
          </div>
          <div class="rectangle-3" />
          <div class="rectangle-4" />
        </div>
      </div>
      <p class="powered-by-real-time">
        Powered By Real-time Analytics,
        <br />
        on-chain Data, And Market Sentiment.
      </p>
    </div>
  </div>
</template>

<script>
import PropertyWrapper from "../../../components/PropertyWrapper.vue";
import Chart1 from "../../../icons/Chart1.vue";
import Chart2 from "../../../icons/Chart2.vue";
import Chart9 from "../../../icons/Chart9.vue";
import Chart10 from "../../../icons/Chart10.vue";
import Chart11 from "../../../icons/Chart11.vue";

export default {
  name: "FrameWrapperByAnima",
  components: {
    PropertyWrapper,
    Chart1,
    Chart2,
    Chart9,
    Chart10,
    Chart11,
  },
};
</script>

<style>
.frame-wrapper-by-anima {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 10px;
  left: 72px;
  position: absolute;
  top: 2791px;
  width: 1319px;
}

.frame-wrapper-by-anima .frame-5 {
  align-items: flex-end;
  display: flex;
  flex: 0 0 auto;
  flex-wrap: wrap;
  gap: 0px -364px;
  margin-right: -366px;
  position: relative;
  width: 1685px;
}

.frame-wrapper-by-anima .rectangle {
  background-color: #ff0000;
  filter: blur(50px);
  height: 663px;
  position: relative;
  width: 1319px;
}

.frame-wrapper-by-anima .rectangle-2 {
  background-color: #000000;
  height: 624px;
  left: 20px;
  position: absolute;
  top: 20px;
  width: 1280px;
}

.frame-wrapper-by-anima .card-crypto {
  align-items: flex-start;
  background: linear-gradient(180deg, rgb(39, 35, 55) 0%, rgba(39, 35, 55, 0) 100%);
  border: 1.93px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(255, 255, 255), rgba(255, 255, 255, 0)) 1;
  border-radius: 15.42px 0px 0px 0px;
  display: flex;
  gap: 8.67px;
  justify-content: center;
  left: 1232px;
  padding: 23.13px;
  position: absolute;
  top: 535px;
  width: 68px;
}

.frame-wrapper-by-anima .component-1 {
  align-self: stretch !important;
  flex: 1 !important;
  flex-grow: 1 !important;
  gap: 15.42px !important;
  margin-left: -0.33px !important;
  margin-top: -2.53px !important;
  width: unset !important;
}

.frame-wrapper-by-anima .component-instance {
  gap: 5.78px !important;
}

.frame-wrapper-by-anima .component-1-instance {
  height: 23.13px !important;
  margin-right: -5.5px !important;
  width: 23.13px !important;
}

.frame-wrapper-by-anima .design-component-instance-node {
  font-size: 17.3px !important;
  letter-spacing: -0.69px !important;
  line-height: 24.3px !important;
  margin-right: -23.28px !important;
  margin-top: -0.96px !important;
}

.frame-wrapper-by-anima .component-2 {
  border-radius: 30.84px !important;
  gap: 7.71px !important;
  margin-right: -28.79px !important;
  padding: 3.86px 7.71px !important;
}

.frame-wrapper-by-anima .component-3 {
  font-size: 13.5px !important;
  letter-spacing: 1.35px !important;
  line-height: 18.9px !important;
  margin-top: -0.96px !important;
}

.frame-wrapper-by-anima .card-crypto-2 {
  align-items: flex-start;
  background: linear-gradient(180deg, rgb(239, 51, 51) 0%, rgba(39, 35, 55, 0) 100%);
  border: 1.93px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(255, 255, 255), rgba(255, 255, 255, 0)) 1;
  border-radius: 15.42px 15.42px 0px 0px;
  display: flex;
  gap: 8.67px;
  justify-content: center;
  left: 1254px;
  padding: 23.13px;
  position: absolute;
  top: 429px;
  width: 46px;
}

.frame-wrapper-by-anima .component-4 {
  align-self: stretch !important;
  flex: 1 !important;
  flex-grow: 1 !important;
  gap: 15.42px !important;
  margin-left: -6.49px !important;
  margin-top: -2.53px !important;
  width: unset !important;
}

.frame-wrapper-by-anima .component-5 {
  height: 23.13px !important;
  margin-right: -22.13px !important;
  width: 23.13px !important;
}

.frame-wrapper-by-anima .component-6 {
  font-size: 17.3px !important;
  letter-spacing: -0.69px !important;
  line-height: 24.3px !important;
  margin-right: -28.92px !important;
  margin-top: -0.96px !important;
}

.frame-wrapper-by-anima .component-7 {
  border-radius: 30.84px !important;
  gap: 7.71px !important;
  margin-right: -23.42px !important;
  padding: 3.86px 7.71px !important;
}

.frame-wrapper-by-anima .chart {
  align-self: stretch !important;
  flex: 1 !important;
  flex-grow: 1 !important;
  margin-right: -5.8px !important;
  margin-top: -2.53px !important;
  position: relative !important;
}

.frame-wrapper-by-anima .overlap-group-wrapper {
  height: 467px;
  left: 20px;
  position: absolute;
  top: 185px;
  width: 1280px;
}

.frame-wrapper-by-anima .overlap-group-2 {
  height: 467px;
  position: relative;
}

.frame-wrapper-by-anima .group-2 {
  height: 115px;
  left: 2px;
  position: absolute;
  top: 352px;
  width: 1181px;
}

.frame-wrapper-by-anima .card-crypto-3 {
  align-items: center;
  background: linear-gradient(180deg, rgb(39, 35, 55) 0%, rgba(39, 35, 55, 0) 100%);
  border: 1.93px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(255, 255, 255), rgba(255, 255, 255, 0)) 1;
  border-radius: 15.42px 15.42px 0px 0px;
  display: flex;
  gap: 8.67px;
  height: 117px;
  justify-content: center;
  left: -2px;
  padding: 23.13px;
  position: absolute;
  top: -2px;
  width: 262px;
}

.frame-wrapper-by-anima .component-8 {
  align-self: stretch !important;
  flex: 1 !important;
  flex-grow: 1 !important;
  gap: 15.42px !important;
  width: unset !important;
}

.frame-wrapper-by-anima .component-9 {
  height: 23.13px !important;
  width: 23.13px !important;
}

.frame-wrapper-by-anima .component-10 {
  font-size: 17.3px !important;
  letter-spacing: -0.69px !important;
  line-height: 24.3px !important;
  margin-right: -72.06px !important;
  margin-top: -0.96px !important;
  width: 144.58px !important;
}

.frame-wrapper-by-anima .component-11 {
  border-radius: 30.84px !important;
  gap: 7.71px !important;
  padding: 3.86px 7.71px !important;
}

.frame-wrapper-by-anima .chart-1 {
  align-self: stretch !important;
  flex: 1 !important;
  flex-grow: 1 !important;
  position: relative !important;
}

.frame-wrapper-by-anima .card-crypto-4 {
  align-items: flex-start;
  background: linear-gradient(180deg, rgb(39, 35, 55) 0%, rgba(39, 35, 55, 0) 100%);
  border: 1.93px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(255, 255, 255), rgba(255, 255, 255, 0)) 1;
  border-radius: 15.42px 15.42px 0px 0px;
  display: flex;
  gap: 8.67px;
  justify-content: center;
  left: 286px;
  padding: 23.13px;
  position: absolute;
  top: -2px;
  width: 281px;
}

.frame-wrapper-by-anima .component-12 {
  align-self: stretch !important;
  flex: 1 !important;
  flex-grow: 1 !important;
  gap: 15.42px !important;
  margin-left: -2.08px !important;
  margin-top: -2.53px !important;
  width: unset !important;
}

.frame-wrapper-by-anima .component-13 {
  font-size: 17.3px !important;
  letter-spacing: -0.69px !important;
  line-height: 24.3px !important;
  margin-right: -62.39px !important;
  margin-top: -0.96px !important;
  width: 144.58px !important;
}

.frame-wrapper-by-anima .icon-instance-node {
  align-self: stretch !important;
  flex: 1 !important;
  flex-grow: 1 !important;
  margin-top: -2.53px !important;
  position: relative !important;
}

.frame-wrapper-by-anima .card-crypto-5 {
  align-items: flex-start;
  background: linear-gradient(180deg, rgb(39, 35, 55) 0%, rgba(39, 35, 55, 0) 100%);
  border: 1.93px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(255, 255, 255), rgba(255, 255, 255, 0)) 1;
  border-radius: 15.42px 15.42px 0px 0px;
  display: flex;
  gap: 8.67px;
  justify-content: center;
  left: 594px;
  padding: 23.13px;
  position: absolute;
  top: -2px;
  width: 281px;
}

.frame-wrapper-by-anima .component-14 {
  flex: 1 !important;
  flex-grow: 1 !important;
  gap: 15.42px !important;
  height: 68.61px !important;
  width: unset !important;
}

.frame-wrapper-by-anima .component-15 {
  font-size: 17.3px !important;
  letter-spacing: -0.69px !important;
  line-height: 24.3px !important;
  margin-right: -4.81px !important;
  margin-top: -0.96px !important;
}

.frame-wrapper-by-anima .chart-2 {
  flex: 1 !important;
  flex-grow: 1 !important;
  height: 69.82px !important;
  position: relative !important;
}

.frame-wrapper-by-anima .card-crypto-6 {
  align-items: flex-start;
  background: linear-gradient(180deg, rgb(39, 35, 55) 0%, rgba(39, 35, 55, 0) 100%);
  border: 1.93px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(255, 255, 255), rgba(255, 255, 255, 0)) 1;
  border-radius: 15.42px 15.42px 0px 0px;
  display: flex;
  gap: 8.67px;
  justify-content: center;
  left: 902px;
  padding: 23.13px;
  position: absolute;
  top: -2px;
  width: 281px;
}

.frame-wrapper-by-anima .component-16 {
  font-size: 17.3px !important;
  letter-spacing: -0.69px !important;
  line-height: 24.3px !important;
  margin-top: -0.96px !important;
}

.frame-wrapper-by-anima .group-3 {
  height: 115px;
  left: 2px;
  position: absolute;
  top: 246px;
  width: 1203px;
}

.frame-wrapper-by-anima .card-crypto-7 {
  align-items: flex-start;
  background: linear-gradient(180deg, rgb(239, 51, 51) 0%, rgba(39, 35, 55, 0) 100%);
  border: 1.93px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(255, 255, 255), rgba(255, 255, 255, 0)) 1;
  border-radius: 15.42px 15.42px 0px 0px;
  display: flex;
  gap: 8.67px;
  justify-content: center;
  left: -2px;
  padding: 23.13px;
  position: absolute;
  top: -2px;
  width: 281px;
}

.frame-wrapper-by-anima .component-17 {
  font-size: 17.3px !important;
  letter-spacing: -0.69px !important;
  line-height: 24.3px !important;
  margin-right: -4.59px !important;
  margin-top: -0.96px !important;
}

.frame-wrapper-by-anima .card-crypto-8 {
  align-items: flex-start;
  background: linear-gradient(180deg, rgb(239, 51, 51) 0%, rgba(39, 35, 55, 0) 100%);
  border: 1.93px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(255, 255, 255), rgba(255, 255, 255, 0)) 1;
  border-radius: 15.42px 15.42px 0px 0px;
  display: flex;
  gap: 8.67px;
  justify-content: center;
  left: 307px;
  padding: 23.13px;
  position: absolute;
  top: -2px;
  width: 281px;
}

.frame-wrapper-by-anima .component-18 {
  align-self: stretch !important;
  flex: 1 !important;
  flex-grow: 1 !important;
  gap: 15.42px !important;
  margin-left: -2.09px !important;
  margin-top: -2.53px !important;
  width: unset !important;
}

.frame-wrapper-by-anima .component-19 {
  font-size: 17.3px !important;
  letter-spacing: -0.69px !important;
  line-height: 24.3px !important;
  margin-right: -62.17px !important;
  margin-top: -0.96px !important;
  width: 144.58px !important;
}

.frame-wrapper-by-anima .card-crypto-9 {
  align-items: flex-start;
  background: linear-gradient(180deg, rgb(239, 51, 51) 0%, rgba(39, 35, 55, 0) 100%);
  border: 1.93px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(255, 255, 255), rgba(255, 255, 255, 0)) 1;
  border-radius: 15.42px 15.42px 0px 0px;
  display: flex;
  gap: 8.67px;
  justify-content: center;
  left: 615px;
  padding: 23.13px;
  position: absolute;
  top: -2px;
  width: 281px;
}

.frame-wrapper-by-anima .card-crypto-10 {
  align-items: flex-start;
  background: linear-gradient(180deg, rgb(239, 51, 51) 0%, rgba(39, 35, 55, 0) 100%);
  border: 1.93px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(255, 255, 255), rgba(255, 255, 255, 0)) 1;
  border-radius: 15.42px 15.42px 0px 0px;
  display: flex;
  gap: 8.67px;
  justify-content: center;
  left: 923px;
  padding: 23.13px;
  position: absolute;
  top: -2px;
  width: 281px;
}

.frame-wrapper-by-anima .group-4 {
  height: 115px;
  left: 38px;
  position: absolute;
  top: 142px;
  width: 1203px;
}

.frame-wrapper-by-anima .card-crypto-11 {
  align-items: flex-start;
  background: linear-gradient(180deg, rgb(249, 112, 112) 0%, rgba(39, 35, 55, 0) 100%);
  border: 1.93px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(255, 255, 255), rgba(255, 255, 255, 0)) 1;
  border-radius: 15.42px 15.42px 0px 0px;
  display: flex;
  gap: 8.67px;
  justify-content: center;
  left: -2px;
  padding: 23.13px;
  position: absolute;
  top: -2px;
  width: 281px;
}

.frame-wrapper-by-anima .card-crypto-12 {
  align-items: flex-start;
  background: linear-gradient(180deg, rgb(249, 112, 112) 0%, rgba(39, 35, 55, 0) 100%);
  border: 1.93px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(255, 255, 255), rgba(255, 255, 255, 0)) 1;
  border-radius: 15.42px 15.42px 0px 0px;
  display: flex;
  gap: 8.67px;
  justify-content: center;
  left: 307px;
  padding: 23.13px;
  position: absolute;
  top: -2px;
  width: 281px;
}

.frame-wrapper-by-anima .card-crypto-13 {
  align-items: flex-start;
  background: linear-gradient(180deg, rgb(249, 112, 112) 0%, rgba(39, 35, 55, 0) 100%);
  border: 1.93px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(255, 255, 255), rgba(255, 255, 255, 0)) 1;
  border-radius: 15.42px 15.42px 0px 0px;
  display: flex;
  gap: 8.67px;
  justify-content: center;
  left: 615px;
  padding: 23.13px;
  position: absolute;
  top: -2px;
  width: 281px;
}

.frame-wrapper-by-anima .card-crypto-14 {
  align-items: flex-start;
  background: linear-gradient(180deg, rgb(249, 112, 112) 0%, rgba(39, 35, 55, 0) 100%);
  border: 1.93px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(255, 255, 255), rgba(255, 255, 255, 0)) 1;
  border-radius: 15.42px 15.42px 0px 0px;
  display: flex;
  gap: 8.67px;
  justify-content: center;
  left: 923px;
  padding: 23.13px;
  position: absolute;
  top: -2px;
  width: 281px;
}

.frame-wrapper-by-anima .rectangle-3 {
  background: linear-gradient(180deg, rgb(11, 7, 27) 0%, rgba(11, 7, 27, 0) 100%);
  height: 459px;
  left: 0;
  position: absolute;
  top: 0;
  transform: rotate(180deg);
  width: 235px;
}

.frame-wrapper-by-anima .rectangle-4 {
  background: linear-gradient(180deg, rgb(11, 7, 27) 0%, rgba(11, 7, 27, 0) 100%);
  height: 459px;
  left: 1030px;
  position: absolute;
  top: 0;
  width: 250px;
}

.frame-wrapper-by-anima .powered-by-real-time {
  color: #ffffff;
  font-family: "Poppins", Helvetica;
  font-size: 43px;
  font-weight: 600;
  height: 79px;
  left: 265px;
  letter-spacing: -1.93px;
  line-height: 49.4px;
  position: absolute;
  text-align: center;
  text-shadow: 0px 1.93px 0.96px #00000026;
  top: 144px;
}
</style>