import React from "react";
import styled from "styled-components";

const StyledSvg = styled.svg`
  &.chart-9 {
    fill: none;
    height: 70;
    width: 115;
  }
`;

export const Chart9 = ({ className }) => {
  return (
    <StyledSvg className={`chart-9 ${className}`} viewBox="0 0 115 70">
      <path
        className="path-2"
        d="M1.84839 32.9556L4.16314 32.9672C6.47789 32.9788 11.1074 33.002 15.7369 34.8321C20.3664 36.6623 24.9959 40.2995 29.6254 41.3875C34.2549 42.4754 38.8844 41.0142 43.5139 40.8785C48.1434 40.7428 52.7729 41.9326 57.4024 45.2367C62.0319 48.5408 66.6614 53.9592 71.2909 58.4859C75.9204 63.0126 80.5499 66.6476 85.1795 68.0615C89.809 69.4754 94.4385 68.6682 99.068 65.8976C103.697 63.1269 108.327 58.393 110.642 56.026L112.956 53.659"
        stroke="#37CBB0"
        strokeLinecap="round"
        strokeWidth="2.40964"
      />
    </StyledSvg>
  );
};
