export { Chart2 } from "./Chart2";
