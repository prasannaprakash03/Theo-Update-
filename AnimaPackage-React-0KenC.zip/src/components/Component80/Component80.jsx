import PropTypes from "prop-types";
import React from "react";
import { useReducer } from "react";
import styled from "styled-components";
import { PropertyFrameWrapper } from "../PropertyFrameWrapper";

const StyledComponent80 = styled.div`
  height: 44px;
  width: 146px;

  & .component-78-instance {
    width: unset !important;
  }

  & .overlap-6 {
    height: 44px;
    position: relative;
    width: 148px;
  }

  & .lucide-arrow-up-2 {
    height: 32px;
    left: 100px;
    position: absolute;
    top: 6px;
    width: 32px;
  }

  & .component-20 {
    height: 44px;
    left: 0;
    position: absolute;
    top: 0;
    width: 146px;
  }

  & .group-9 {
    height: 44px;
    width: 148px;
  }

  & .overlap-group-5 {
    border-radius: 57px;
    box-shadow: 0px 2px 8px 1px #ffffff40;
    height: 44px;
    position: relative;
    width: 146px;
  }

  & .text-wrapper-14 {
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 16px;
    font-weight: 400;
    left: 17px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 15px;
    white-space: nowrap;
  }
`;

export const Component80 = ({ property1, className }) => {
  const [state, dispatch] = useReducer(reducer, {
    property1: property1 || "frame-2147223995",
  });

  return (
    <StyledComponent80
      className={`component-80 ${className}`}
      onMouseLeave={() => {
        dispatch("mouse_leave");
      }}
      onMouseEnter={() => {
        dispatch("mouse_enter");
      }}
    >
      {state.property1 === "frame-2147223995" && (
        <PropertyFrameWrapper
          className="component-78-instance"
          property1="frame-2147223995"
          text="TRY THEO"
        />
      )}

      {state.property1 === "frame-2147223996" && (
        <div className="overlap-6">
          <img
            className="lucide-arrow-up-2"
            alt="Lucide arrow up"
            src="/img/lucide-arrow-up-3.svg"
          />

          <div className="component-20">
            <div className="group-9">
              <div className="overlap-group-5">
                <div className="text-wrapper-14">TRY THEO</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </StyledComponent80>
  );
};

function reducer(state, action) {
  switch (action) {
    case "mouse_enter":
      return {
        ...state,
        property1: "frame-2147223996",
      };

    case "mouse_leave":
      return {
        ...state,
        property1: "frame-2147223995",
      };
  }

  return state;
}

Component80.propTypes = {
  property1: PropTypes.oneOf(["frame-2147223996", "frame-2147223995"]),
};
