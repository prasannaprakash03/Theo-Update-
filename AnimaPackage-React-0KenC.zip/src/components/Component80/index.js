export { Component80 } from "./Component80";
