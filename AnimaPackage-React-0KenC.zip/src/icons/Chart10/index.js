export { Chart10 } from "./Chart10";
