export { Chart1 } from "./Chart1";
