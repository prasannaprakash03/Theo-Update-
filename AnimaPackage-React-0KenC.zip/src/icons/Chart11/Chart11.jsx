import React from "react";
import styled from "styled-components";

const StyledSvg = styled.svg`
  &.chart-11 {
    fill: none;
    height: 70px;
    width: 115px;
  }
`;

export const Chart11 = ({ className }) => {
  return (
    <StyledSvg
      className={`chart-11 ${className}`}
      viewBox="0 0 115 70"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path-2"
        d="M1.99976 51.1986L4.31903 53.7162C6.63831 56.2339 11.2769 61.2691 15.9154 60.0875C20.554 58.9059 25.1925 51.5073 29.8311 50.6C34.4696 49.6928 39.1082 55.2768 43.7467 55.2728C48.3853 55.2688 53.0239 49.6768 57.6624 49.4107C62.301 49.1446 66.9395 54.2043 71.5781 59.512C76.2166 64.8196 80.8552 70.3752 85.4937 68.2991C90.1323 66.223 94.7708 56.5153 99.4094 53.8043C104.048 51.0933 108.687 55.3789 111.006 57.5217L113.325 59.6645"
        stroke="#D82C60"
        strokeLinecap="round"
        strokeWidth="2.40964"
      />
    </StyledSvg>
  );
};
