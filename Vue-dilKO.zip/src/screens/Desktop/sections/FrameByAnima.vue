<template>
  <div class="frame-by-anima">
    <div class="component">
      <div class="overlap">
        <div class="overlap-group">
          <img class="star" alt="Star" src="/img/star.png" />
          <div class="ellipse" />
          <div class="div" />
          <div class="ellipse-2" />
          <img class="mask-group" alt="Mask group" src="/img/mask-group.png" />
          <div class="group" />
          <img class="eth-red" alt="Eth red" src="/img/eth-red-3.png" />
          <img class="binanace-red" alt="Binanace red" src="/img/binanace-red-9.png" />
          <img class="img" alt="Binanace red" src="/img/binanace-red-10.png" />
          <img class="binanace-red-2" alt="Binanace red" src="/img/binanace-red-11.png" />
          <img class="binanace-red-3" alt="Binanace red" src="/img/binanace-red-12.png" />
          <img class="polygon" alt="Polygon" src="/img/polygon-5.svg" />
          <div class="frame">
            <div class="text-wrapper">$ 1</div>
          </div>
          <img class="polygon-2" alt="Polygon" src="/img/polygon-9.svg" />
          <div class="div-wrapper">
            <div class="text-wrapper-2">$ 2056</div>
          </div>
          <img class="polygon-3" alt="Polygon" src="/img/polygon-9.svg" />
          <img class="polygon-4" alt="Polygon" src="/img/polygon-5.svg" />
          <div class="frame-2">
            <div class="text-wrapper-3">$ 1.01</div>
          </div>
          <img class="theo-red" alt="Theo red" src="/img/theo-red-2.png" />
          <p class="p">The Money Manager For Everyone</p>
        </div>
        <img class="polygon-5" alt="Polygon" src="/img/polygon-5.svg" />
        <div class="frame-3">
          <div class="text-wrapper-2">$ 168.86</div>
        </div>
        <div class="text-wrapper-4">From $100 To Millions</div>
        <div class="frame-4">
          <div class="text-wrapper-5">$ 98,620</div>
        </div>
        <div class="component-wrapper">
          <PropertyFrameWrapper
            class="component-78"
            property1="frame-2147223995"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import PropertyFrameWrapper from "../../../components/PropertyFrameWrapper.vue";

export default {
  name: "FrameByAnima",
  components: {
    PropertyFrameWrapper,
  },
};
</script>

<style>
.frame-by-anima {
  height: 793px;
  left: 0;
  position: absolute;
  top: 0;
  width: 1889px;
}

.frame-by-anima .component {
  background-color: #000000;
  height: 793px;
}

.frame-by-anima .overlap {
  height: 769px;
  position: relative;
  top: 24px;
  width: 1889px;
}

.frame-by-anima .overlap-group {
  height: 769px;
  left: 0;
  position: absolute;
  top: 0;
  width: 1889px;
}

.frame-by-anima .star {
  height: 276px;
  left: 0;
  position: absolute;
  top: 0;
  width: 1440px;
}

.frame-by-anima .ellipse {
  border: 3px solid;
  border-color: #ffffff;
  border-radius: 298px;
  box-shadow: inset 0px 0px 48.87px #ffffff40;
  height: 596px;
  left: 1167px;
  opacity: 0.1;
  position: absolute;
  top: 97px;
  width: 596px;
}

.frame-by-anima .div {
  border: 3px solid;
  border-color: #ffffff;
  border-radius: 366px;
  box-shadow: inset 0px 0px 48.87px #ffffff40;
  height: 732px;
  left: 1099px;
  opacity: 0.1;
  position: absolute;
  top: 29px;
  width: 732px;
}

.frame-by-anima .ellipse-2 {
  background-color: #ef4444;
  border-radius: 239px;
  filter: blur(120px);
  height: 478px;
  left: 1228px;
  position: absolute;
  top: 155px;
  transform: rotate(28.67deg);
  width: 478px;
}

.frame-by-anima .mask-group {
  height: 478px;
  left: 1232px;
  position: absolute;
  top: 151px;
  width: 208px;
}

.frame-by-anima .group {
  background: linear-gradient(
    180deg,
    rgb(255, 255, 255) 0%,
    rgb(239, 68, 68) 39.83%,
    rgb(109.7, 52.76, 239.32) 75.73%,
    rgb(115.82, 109.96, 213.48) 100%
  );
  border-radius: 202px;
  filter: blur(101.42px);
  height: 404px;
  left: 1402px;
  position: absolute;
  top: 192px;
  transform: rotate(45deg);
  width: 404px;
}

.frame-by-anima .eth-red {
  height: 56px;
  left: 1121px;
  object-fit: cover;
  position: absolute;
  top: 184px;
  width: 56px;
}

.frame-by-anima .binanace-red {
  height: 53px;
  left: 1072px;
  object-fit: cover;
  position: absolute;
  top: 376px;
  width: 53px;
}

.frame-by-anima .img {
  height: 55px;
  left: 1123px;
  object-fit: cover;
  position: absolute;
  top: 562px;
  width: 55px;
}

.frame-by-anima .binanace-red-2 {
  height: 55px;
  left: 1304px;
  object-fit: cover;
  position: absolute;
  top: 24px;
  width: 55px;
}

.frame-by-anima .binanace-red-3 {
  height: 55px;
  left: 1322px;
  object-fit: cover;
  position: absolute;
  top: 714px;
  width: 55px;
}

.frame-by-anima .polygon {
  height: 14px;
  left: 1281px;
  position: absolute;
  top: 48px;
  width: 13px;
}

.frame-by-anima .frame {
  background-color: #ffffff;
  border-radius: 20px;
  height: 50px;
  left: 1214px;
  position: absolute;
  top: 30px;
  width: 54px;
}

.frame-by-anima .text-wrapper {
  color: #1a1a1a;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 20px;
  font-weight: 400;
  left: 15px;
  letter-spacing: -1px;
  line-height: 26px;
  position: absolute;
  top: 11px;
  white-space: nowrap;
}

.frame-by-anima .polygon-2 {
  height: 14px;
  left: 1100px;
  position: absolute;
  top: 208px;
  width: 13px;
}

.frame-by-anima .div-wrapper {
  background-color: #f97070;
  border-radius: 100px;
  height: 50px;
  left: 992px;
  position: absolute;
  top: 190px;
  width: 100px;
}

.frame-by-anima .text-wrapper-2 {
  color: #ffffff;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 20px;
  font-weight: 400;
  left: 20px;
  letter-spacing: -1px;
  line-height: 26px;
  position: absolute;
  top: 11px;
  white-space: nowrap;
}

.frame-by-anima .polygon-3 {
  height: 14px;
  left: 1094px;
  position: absolute;
  top: 585px;
  width: 13px;
}

.frame-by-anima .polygon-4 {
  height: 14px;
  left: 1297px;
  position: absolute;
  top: 737px;
  width: 13px;
}

.frame-by-anima .frame-2 {
  background-color: #ffffff;
  border-radius: 100px;
  height: 50px;
  left: 1211px;
  position: absolute;
  top: 719px;
  width: 77px;
}

.frame-by-anima .text-wrapper-3 {
  color: #1a1a1a;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 20px;
  font-weight: 400;
  left: 20px;
  letter-spacing: -1px;
  line-height: 26px;
  position: absolute;
  top: 11px;
  white-space: nowrap;
}

.frame-by-anima .theo-red {
  height: 93px;
  left: 80px;
  object-fit: cover;
  position: absolute;
  top: 36px;
  width: 93px;
}

.frame-by-anima .p {
  color: #ffffff;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 70px;
  font-weight: 400;
  left: 83px;
  letter-spacing: -1px;
  line-height: 91px;
  position: absolute;
  top: 222px;
  width: 754px;
}

.frame-by-anima .polygon-5 {
  height: 14px;
  left: 1044px;
  position: absolute;
  top: 394px;
  width: 13px;
}

.frame-by-anima .frame-3 {
  background-color: #f97070;
  border-radius: 100px;
  height: 50px;
  left: 986px;
  position: absolute;
  top: 567px;
  width: 100px;
}

.frame-by-anima .text-wrapper-4 {
  -webkit-background-clip: text !important;
  -webkit-text-fill-color: transparent;
  background: linear-gradient(180deg, rgb(137, 29.23, 29.23) 0%, rgb(255, 206.34, 206.34) 98%);
  background-clip: text;
  color: transparent;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 44px;
  font-weight: 400;
  left: 80px;
  letter-spacing: -1px;
  line-height: 57.2px;
  position: absolute;
  text-fill-color: transparent;
  top: 433px;
  white-space: nowrap;
}

.frame-by-anima .frame-4 {
  background-color: #ffffff;
  border-radius: 100px;
  height: 50px;
  left: 936px;
  position: absolute;
  top: 376px;
  width: 100px;
}

.frame-by-anima .text-wrapper-5 {
  color: #1a1a1a;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 20px;
  font-weight: 400;
  left: 13px;
  letter-spacing: -1px;
  line-height: 26px;
  position: absolute;
  top: 11px;
  white-space: nowrap;
}

.frame-by-anima .component-wrapper {
  height: 44px;
  left: 79px;
  position: absolute;
  top: 519px;
  width: 146px;
}

.frame-by-anima .component-78 {
  width: unset !important;
}
</style>