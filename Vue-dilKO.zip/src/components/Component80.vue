<template>
  <div :class="['component-80', className]">
    <PropertyFrameWrapper
      v-if="property1 === 'frame-2147223995'"
      class="component-78-instance"
      property1="frame-2147223995"
      text="TRY THEO"
    />
    <div v-if="property1 === 'frame-2147223996'" class="overlap-6">
      <img
        class="lucide-arrow-up-2"
        alt="Lucide arrow up"
        src="/img/lucide-arrow-up-3.svg"
      />
      <div class="component-20">
        <div class="group-9">
          <div class="overlap-group-5">
            <div class="text-wrapper-14">TRY THEO</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import PropertyFrameWrapper from "./PropertyFrameWrapper.vue";

export default {
  name: "Component80",
  components: {
    PropertyFrameWrapper,
  },
  props: {
    property1: {
      type: String,
      validator: function (value) {
        return ["frame-2147223996", "frame-2147223995"].indexOf(value) !== -1;
      },
    },
    className: {
      type: String,
      default: "",
    },
  },
};
</script>

<style>
.component-80 {
  height: 44px;
  width: 146px;
}

.component-80 .component-78-instance {
  width: unset !important;
}

.component-80 .overlap-6 {
  height: 44px;
  position: relative;
  width: 148px;
}

.component-80 .lucide-arrow-up-2 {
  height: 32px;
  left: 100px;
  position: absolute;
  top: 6px;
  width: 32px;
}

.component-80 .component-20 {
  height: 44px;
  left: 0;
  position: absolute;
  top: 0;
  width: 146px;
}

.component-80 .group-9 {
  height: 44px;
  width: 148px;
}

.component-80 .overlap-group-5 {
  border-radius: 57px;
  box-shadow: 0px 2px 8px 1px #ffffff40;
  height: 44px;
  position: relative;
  width: 146px;
}

.component-80 .text-wrapper-14 {
  color: #ffffff;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 16px;
  font-weight: 400;
  left: 17px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 15px;
  white-space: nowrap;
}
</style>