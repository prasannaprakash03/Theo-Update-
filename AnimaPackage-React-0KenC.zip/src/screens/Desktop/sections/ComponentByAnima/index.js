export { ComponentByAnima } from "./ComponentByAnima";
