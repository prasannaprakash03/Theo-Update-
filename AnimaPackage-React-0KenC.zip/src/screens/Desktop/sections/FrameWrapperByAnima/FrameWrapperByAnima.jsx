import React from "react";
import styled from "styled-components";
import { PropertyWrapper } from "../../../../components/PropertyWrapper";
import { Chart1 } from "../../../../icons/Chart1";
import { Chart2 } from "../../../../icons/Chart2";
import { Chart9 } from "../../../../icons/Chart9";
import { Chart10 } from "../../../../icons/Chart10";
import { Chart11 } from "../../../../icons/Chart11";

const FrameWrapper = styled.div`
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 10px;
  left: 72px;
  position: absolute;
  top: 2791px;
  width: 1319px;
`;

const Frame5 = styled.div`
  align-items: flex-end;
  display: flex;
  flex: 0 0 auto;
  flex-wrap: wrap;
  gap: 0px -364px;
  margin-right: -366px;
  position: relative;
  width: 1685px;
`;

const Rectangle = styled.div`
  background-color: #ff0000;
  filter: blur(50px);
  height: 663px;
  position: relative;
  width: 1319px;
`;

const Rectangle2 = styled.div`
  background-color: #000000;
  height: 624px;
  left: 20px;
  position: absolute;
  top: 20px;
  width: 1280px;
`;

const CardCrypto = styled.div`
  align-items: flex-start;
  background: linear-gradient(180deg, rgb(39, 35, 55) 0%, rgba(39, 35, 55, 0) 100%);
  border: 1.93px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(255, 255, 255), rgba(255, 255, 255, 0)) 1;
  border-radius: 15.42px 0px 0px 0px;
  display: flex;
  gap: 8.67px;
  justify-content: center;
  left: 1232px;
  padding: 23.13px;
  position: absolute;
  top: 535px;
  width: 68px;
`;

const CardCrypto2 = styled(CardCrypto)`
  background: linear-gradient(180deg, rgb(239, 51, 51) 0%, rgba(39, 35, 55, 0) 100%);
  left: 1254px;
  top: 429px;
  width: 46px;
`;

const OverlapGroupWrapper = styled.div`
  height: 467px;
  left: 20px;
  position: absolute;
  top: 185px;
  width: 1280px;
`;

const OverlapGroup2 = styled.div`
  height: 467px;
  position: relative;
`;

const Group2 = styled.div`
  height: 115px;
  left: 2px;
  position: absolute;
  top: 352px;
  width: 1181px;
`;

const Group3 = styled(Group2)`
  top: 246px;
`;

const Group4 = styled(Group2)`
  top: 142px;
`;

const PoweredByRealTime = styled.p`
  color: #ffffff;
  font-family: "Poppins", Helvetica;
  font-size: 43px;
  font-weight: 600;
  height: 79px;
  left: 265px;
  letter-spacing: -1.93px;
  line-height: 49.4px;
  position: absolute;
  text-align: center;
  text-shadow: 0px 1.93px 0.96px #00000026;
  top: 144px;
`;

export const FrameWrapperByAnima = () => {
  return (
    <FrameWrapper>
      <Frame5>
        <Rectangle />
        <Rectangle2 />
        <CardCrypto>
          <PropertyWrapper
            ETHClassName="component-1-instance"
            className="component-1"
            divClassName="design-component-instance-node"
            divClassNameOverride="component-3"
            frameClassName="component-2"
            property1="three"
            tether="/img/tether-1.svg"
            text="U"
            titleClassName="component-instance"
          />
        </CardCrypto>
        <CardCrypto2>
          <PropertyWrapper
            ETHClassName="component-5"
            className="component-4"
            divClassName="component-6"
            divClassNameOverride="component-3"
            frameClassName="component-7"
            property1="two"
            text1=""
            text2="4"
            titleClassName="component-instance"
            uniswap="/img/uniswap-1.svg"
          />
          <Chart2 className="chart" />
        </CardCrypto2>
        <OverlapGroupWrapper>
          <OverlapGroup2>
            <Group2>
              <CardCrypto>
                <PropertyWrapper
                  ETHClassName="component-9"
                  LUNA="/img/luna-1.svg"
                  className="component-8"
                  divClassName="component-10"
                  divClassNameOverride="component-3"
                  frameClassName="component-11"
                  property1="four"
                  titleClassName="component-instance"
                />
                <Chart1 className="chart-1" />
              </CardCrypto>
              <CardCrypto>
                <PropertyWrapper
                  ETH="/img/eth-1.svg"
                  ETHClassName="component-9"
                  className="component-12"
                  divClassName="component-13"
                  divClassNameOverride="component-3"
                  frameClassName="component-11"
                  property1="six"
                  titleClassName="component-instance"
                />
                <Chart2 className="icon-instance-node" />
              </CardCrypto>
              <CardCrypto>
                <PropertyWrapper
                  ETHClassName="component-9"
                  className="component-14"
                  divClassName="component-15"
                  divClassName="component-16"
                  divClassName="component-3"
                  doge="/img/doge-1.svg"
                  frameClassName="component-11"
                  property1="one"
                  text2="45%"
                  titleClassName="component-instance"
                />
                <Chart9 className="chart-2" />
              </CardCrypto>
              <CardCrypto>
                <PropertyWrapper
                  ETHClassName="component-9"
                  className="component-14"
                  divClassName="component-16"
                  divClassName="component-3"
                  frameClassName="component-11"
                  property1="two"
                  text1="UNI/USD"
                  text2="45%"
                  titleClassName="component-instance"
                  uniswap="/img/uniswap-2.svg"
                />
                <Chart2 className="chart-2" />
              </CardCrypto>
            </Group2>
            <Group3>
              <CardCrypto>
                <PropertyWrapper
                  ETHClassName="component-9"
                  className="component-14"
                  divClassName="component-17"
                  divClassNameOverride="component-3"
                  doge="/img/doge-2.svg"
                  frameClassName="component-11"
                  property1="one"
                  text2="45%"
                  titleClassName="component-instance"
                />
                <Chart9 className="chart-2" />
              </CardCrypto>
              <CardCrypto>
                <PropertyWrapper
                  ETH="/img/eth-2.svg"
                  ETHClassName="component-9"
                  className="component-18"
                  divClassName="component-19"
                  divClassNameOverride="component-3"
                  frameClassName="component-11"
                  property1="six"
                  titleClassName="component-instance"
                />
                <Chart2 className="icon-instance-node" />
              </CardCrypto>
              <CardCrypto>
                <PropertyWrapper
                  ETHClassName="component-9"
                  className="component-14"
                  divClassName="component-16"
                  divClassName="component-3"
                  frameClassName="component-11"
                  property1="three"
                  tether="/img/tether-2.svg"
                  text="USDT/USD"
                  titleClassName="component-instance"
                />
                <Chart10 className="chart-2" />
              </CardCrypto>
              <CardCrypto>
                <PropertyWrapper
                  ETHClassName="component-9"
                  LUNA="/img/luna-2.svg"
                  className="component-18"
                  divClassName="component-19"
                  divClassNameOverride="component-3"
                  frameClassName="component-11"
                  property1="four"
                  titleClassName="component-instance"
                />
                <Chart1 className="icon-instance-node" />
              </CardCrypto>
            </Group3>
            <Group4>
              <CardCrypto>
                <PropertyWrapper
                  ETHClassName="component-9"
                  className="component-14"
                  divClassName="component-17"
                  divClassNameOverride="component-3"
                  doge="/img/doge-3.svg"
                  frameClassName="component-11"
                  property1="one"
                  text2="45%"
                  titleClassName="component-instance"
                />
                <Chart9 className="chart-2" />
              </CardCrypto>
              <CardCrypto>
                <PropertyWrapper
                  ETHClassName="component-9"
                  className="component-18"
                  divClassName="component-16"
                  divClassNameOverride="component-3"
                  frameClassName="component-11"
                  property1="three"
                  tether="/img/tether-3.svg"
                  text="USDT/USD"
                  titleClassName="component-instance"
                />
                <Chart10 className="icon-instance-node" />
              </CardCrypto>
              <CardCrypto>
                <PropertyWrapper
                  ETHClassName="component-9"
                  className="component-14"
                  divClassName="component-19"
                  divClassNameOverride="component-3"
                  frameClassName="component-11"
                  property1="five"
                  solana="/img/solana-1.svg"
                  titleClassName="component-instance"
                />
                <Chart11 className="chart-2" />
              </CardCrypto>
              <CardCrypto>
                <PropertyWrapper
                  ETHClassName="component-9"
                  LUNA="/img/luna-3.svg"
                  className="component-14"
                  divClassName="component-19"
                  divClassNameOverride="component-3"
                  frameClassName="component-11"
                  property1="four"
                  titleClassName="component-instance"
                />
                <Chart1 className="chart-2" />
              </CardCrypto>
            </Group4>
            <Rectangle />
            <Rectangle2 />
          </OverlapGroup2>
        </OverlapGroupWrapper>
        <PoweredByRealTime>
          Powered By Real-time Analytics,
          <br />
          on-chain Data, And Market Sentiment.
        </PoweredByRealTime>
      </Frame5>
    </FrameWrapper>
  );
};
