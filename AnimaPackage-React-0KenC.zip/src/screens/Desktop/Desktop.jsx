import React from "react";
import styled from "styled-components";
import { Component80 } from "../../components/Component80";
import { PropertyFrameWrapper } from "../../components/PropertyFrameWrapper";
import { ComponentByAnima } from "./sections/ComponentByAnima";
import { FrameByAnima } from "./sections/FrameByAnima";
import { FrameWrapperByAnima } from "./sections/FrameWrapperByAnima";

const StyledDesktop = styled.div`
  background-color: #000000;
  display: flex;
  flex-direction: row;
  justify-content: center;
  width: 100%;

  .div-2 {
    background-color: #000000;
    height: 6732px;
    overflow: hidden;
    position: relative;
    width: 1440px;
  }

  .overlap-7 {
    height: 1408px;
    left: 0;
    position: absolute;
    top: 5079px;
    width: 1440px;
  }

  .group-10 {
    background-image: url(../../../static/img/ellipse-60.svg);
    background-size: 100% 100%;
    height: 1216px;
    left: 95px;
    position: absolute;
    top: 0;
    width: 1216px;
  }

  .overlap-8 {
    height: 1216px;
    position: relative;
  }

  .glow-radial {
    height: 1216px;
    left: 0;
    position: absolute;
    top: 0;
    width: 1216px;
  }

  .overlap-group-6 {
    background-image: url(../../../static/img/ellipse-blur.svg);
    background-size: 100% 100%;
    height: 1296px;
    left: -40px;
    position: relative;
    top: -40px;
    width: 1296px;
  }

  .ellipse-blur {
    height: 1296px;
    left: 0;
    position: absolute;
    top: 0;
    width: 1296px;
  }

  .ellipse-3 {
    border: 1px solid;
    border-color: #ff2929;
    border-radius: 608px;
    height: 1216px;
    left: 0;
    position: absolute;
    top: 0;
    width: 1216px;
  }

  .ellipse-4 {
    height: 968px;
    left: 112px;
    position: absolute;
    top: 124px;
    width: 992px;
  }

  .ellipse-5 {
    height: 753px;
    left: 250px;
    position: absolute;
    top: 235px;
    width: 716px;
  }

  .frame-6 {
    height: 58px;
    left: 1029px;
    position: absolute;
    top: 642px;
    width: 45px;
  }

  .ellipse-6 {
    height: 45px;
    left: 0;
    object-fit: cover;
    position: absolute;
    top: 0;
    width: 45px;
  }

  .ellipse-7 {
    background-color: #d9d9d9;
    border-radius: 5px;
    height: 10px;
    left: 18px;
    position: absolute;
    top: 48px;
    width: 10px;
  }

  .frame-7 {
    height: 58px;
    left: 216px;
    position: absolute;
    top: 696px;
    width: 45px;
  }

  .frame-8 {
    background-color: #ff0000;
    border: 1px solid;
    border-color: transparent;
    border-image: linear-gradient(to bottom, rgb(82.87, 64.47, 128.86), rgba(119, 103, 159, 0)) 1;
    border-radius: 99px;
    height: 69px;
    left: 773px;
    position: absolute;
    top: 89px;
    width: 520px;
  }

  .ellipse-8 {
    height: 45px;
    left: 12px;
    object-fit: cover;
    position: absolute;
    top: 12px;
    width: 45px;
  }

  .frame-9 {
    height: 37px;
    left: 69px;
    position: absolute;
    top: 16px;
    width: 427px;
  }

  .text-wrapper-15 {
    color: #ffffff;
    font-family: "Poppins", Helvetica;
    font-size: 16px;
    font-weight: 700;
    left: 0;
    letter-spacing: 0;
    line-height: 18px;
    position: absolute;
    top: -1px;
    white-space: nowrap;
  }

  .text-wrapper-16 {
    color: #ffffff;
    font-family: "Poppins", Helvetica;
    font-size: 16px;
    font-weight: 400;
    left: 0;
    letter-spacing: 0;
    line-height: normal;
    opacity: 0.7;
    position: absolute;
    top: 25px;
    white-space: nowrap;
  }

  .frame-10 {
    background-color: #ff0000;
    border: 1px solid;
    border-color: transparent;
    border-image: linear-gradient(to bottom, rgb(82.87, 64.47, 128.86), rgba(119, 103, 159, 0)) 1;
    border-radius: 99px;
    height: 69px;
    left: 1078px;
    position: absolute;
    top: 416px;
    width: 304px;
  }

  .frame-11 {
    height: 41px;
    left: 69px;
    position: absolute;
    top: 14px;
    width: 211px;
  }

  .frame-12 {
    background-color: #ff0101;
    border: 1px solid;
    border-color: transparent;
    border-image: linear-gradient(to bottom, rgb(82.87, 64.47, 128.86), rgba(119, 103, 159, 0)) 1;
    border-radius: 99px;
    height: 69px;
    left: 238px;
    position: absolute;
    top: 205px;
    width: 282px;
  }

  .frame-13 {
    height: 41px;
    left: 69px;
    position: absolute;
    top: 14px;
    width: 189px;
  }

  .frame-14 {
    background-color: #ff0000;
    border: 1px solid;
    border-color: transparent;
    border-image: linear-gradient(to bottom, rgb(82.87, 64.47, 128.86), rgba(119, 103, 159, 0)) 1;
    border-radius: 99px;
    height: 79px;
    left: 59px;
    position: absolute;
    top: 527px;
    width: 437px;
  }

  .ellipse-9 {
    height: 45px;
    left: 12px;
    object-fit: cover;
    position: absolute;
    top: 17px;
    width: 45px;
  }

  .frame-15 {
    height: 55px;
    left: 69px;
    position: absolute;
    top: 12px;
    width: 344px;
  }

  .i-finally-trade-with {
    color: #ffffff;
    font-family: "Poppins", Helvetica;
    font-size: 16px;
    font-weight: 700;
    left: 0;
    letter-spacing: 0;
    line-height: 18px;
    position: absolute;
    top: -1px;
  }

  .text-wrapper-17 {
    color: #ffffff;
    font-family: "Poppins", Helvetica;
    font-size: 16px;
    font-weight: 400;
    left: 0;
    letter-spacing: 0;
    line-height: normal;
    opacity: 0.7;
    position: absolute;
    top: 43px;
    white-space: nowrap;
  }

  .text-wrapper-18 {
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 60px;
    font-weight: 400;
    left: 549px;
    letter-spacing: 0;
    line-height: 65px;
    position: absolute;
    text-align: center;
    top: 420px;
    white-space: nowrap;
  }

  .component-80-instance {
    left: 629px !important;
    position: absolute !important;
    top: 513px !important;
  }

  .frame-16 {
    height: 58px;
    left: 420px;
    position: absolute;
    top: 5px;
    width: 45px;
  }

  .frame-17 {
    height: 58px;
    left: 888px;
    position: absolute;
    top: 253px;
    width: 45px;
  }

  .rectangle-6 {
    background-color: #0f0f10;
    filter: blur(150px);
    height: 582px;
    left: 0;
    position: absolute;
    top: 779px;
    width: 1440px;
  }

  .frequently-asked {
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 40px;
    font-weight: 400;
    left: 122px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 904px;
  }

  .get-smarter-with {
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 40px;
    font-weight: 400;
    left: 889px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 896px;
  }

  .text-wrapper-19 {
    color: #ffffff;
    font-family: "Poppins", Helvetica;
    font-size: 27px;
    font-weight: 500;
    left: 889px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 1073px;
  }

  .text-wrapper-20 {
    color: #ffffff;
    font-family: "Poppins", Helvetica;
    font-size: 27px;
    font-weight: 500;
    left: 888px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 1217px;
  }

  .rectangle-7 {
    background-color: #ffffff;
    border: 1px solid;
    border-color: #b0b0b0;
    border-radius: 15px;
    height: 72px;
    left: 118px;
    position: absolute;
    top: 1057px;
    width: 672px;
  }

  .rectangle-8 {
    background-color: #ffffff;
    border: 1px solid;
    border-color: #b0b0b0;
    border-radius: 15px;
    height: 72px;
    left: 118px;
    position: absolute;
    top: 1336px;
    width: 672px;
  }

  .rectangle-9 {
    background-color: #ffffff;
    border: 1px solid;
    border-color: #b0b0b0;
    border-radius: 15px;
    height: 154px;
    left: 118px;
    position: absolute;
    top: 1150px;
    width: 672px;
  }

  .text-wrapper-21 {
    color: #000000;
    font-family: "Poppins", Helvetica;
    font-size: 20px;
    font-weight: 500;
    left: 142px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 1077px;
  }

  .text-wrapper-22 {
    color: #000000;
    font-family: "Poppins", Helvetica;
    font-size: 20px;
    font-weight: 500;
    left: 142px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 1356px;
  }

  .text-wrapper-23 {
    color: #000000;
    font-family: "Poppins", Helvetica;
    font-size: 16px;
    font-weight: 400;
    left: 140px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 1226px;
  }

  .text-wrapper-24 {
    color: #ef3333;
    font-family: "Poppins", Helvetica;
    font-size: 20px;
    font-weight: 500;
    left: 140px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 1178px;
  }

  .group-11 {
    height: 40px;
    left: 726px;
    position: absolute;
    top: 1073px;
    width: 40px;
  }

  .overlap-9 {
    border-radius: 20px;
    height: 40px;
    position: relative;
  }

  .ellipse-10 {
    background-color: #ffffff;
    border: 1px solid;
    border-color: #060548;
    border-radius: 20px;
    height: 40px;
    left: 0;
    position: absolute;
    top: 0;
    transform: rotate(180deg);
    width: 40px;
  }

  .ep-arrow-left-bold {
    height: 24px;
    left: 8px;
    position: absolute;
    top: 8px;
    width: 24px;
  }

  .group-12 {
    height: 40px;
    left: 726px;
    position: absolute;
    top: 1352px;
    width: 40px;
  }

  .group-13 {
    height: 40px;
    left: 726px;
    position: absolute;
    top: 1174px;
    width: 40px;
  }

  .ellipse-11 {
    background-color: #ef3333;
    border: 1px solid;
    border-radius: 20px;
    height: 40px;
    left: 0;
    position: absolute;
    top: 0;
    transform: rotate(-180deg);
    width: 40px;
  }

  .component-21 {
    left: 895px !important;
    position: absolute !important;
    top: 1135px !important;
  }

  .component-22 {
    height: 44px;
    left: 886px;
    position: absolute;
    top: 1292px;
    width: 146px;
  }

  .overlap-10 {
    height: 44px;
    position: relative;
    width: 148px;
  }

  .group-14 {
    height: 44px;
    left: 0;
    position: absolute;
    top: 0;
    width: 148px;
  }

  .overlap-group-7 {
    border-radius: 57px;
    box-shadow: 0px 2px 8px 1px #ffffff40;
    height: 44px;
    position: relative;
    width: 146px;
  }

  .TRY-THEO-2 {
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 16px;
    font-weight: 400;
    left: 17px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 15px;
    white-space: nowrap;
  }

  .lucide-arrow-up-3 {
    height: 24px;
    left: 114px;
    position: absolute;
    top: 10px;
    width: 24px;
  }

  .why-choose-agent {
    color: transparent;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 64px;
    font-weight: 400;
    left: 363px;
    letter-spacing: -1px;
    line-height: 83.2px;
    position: absolute;
    top: 1774px;
    white-space: nowrap;
  }

  .span {
    color: #ffffff;
    letter-spacing: -0.64px;
  }

  .text-wrapper-25 {
    color: #ef3333;
    font-family: "Akisa-Regular", Helvetica;
    letter-spacing: -0.64px;
  }

  .text-wrapper-26 {
    color: #ffffff;
    font-family: "Akisa-Regular", Helvetica;
    letter-spacing: -0.64px;
  }

  .text-wrapper-27 {
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 64px;
    font-weight: 400;
    left: 464px;
    letter-spacing: -1px;
    line-height: 83.2px;
    position: absolute;
    top: 2642px;
    white-space: nowrap;
  }

  .the-power-OF-a-money {
    color: #b0b0b0;
    font-family: "Poppins", Helvetica;
    font-size: 30px;
    font-weight: 600;
    height: 32px;
    left: 460px;
    letter-spacing: -2px;
    line-height: 31.8px;
    position: absolute;
    text-align: center;
    top: 1857px;
    white-space: nowrap;
    width: 520px;
  }

  .frame-18 {
    background-color: #ef3333;
    border: 1px solid;
    border-color: transparent;
    height: 423px;
    left: 3227px;
    overflow: hidden;
    position: absolute;
    top: 1334px;
    width: 300px;
  }

  .frame-19 {
    height: 421px;
    left: -3256px;
    position: absolute;
    top: -1335px;
    width: 298px;
  }

  .overlap-11 {
    height: 436px;
    left: -69px;
    position: absolute;
    top: 257px;
    width: 436px;
  }

  .group-15 {
    height: 436px;
    left: 0;
    position: absolute;
    top: 0;
    width: 436px;
  }

  .overlap-group-8 {
    height: 436px;
    position: relative;
  }

  .rectangle-10 {
    background: linear-gradient(
      180deg,
      rgb(255, 255, 255) 0%,
      rgb(239, 68, 68) 39.83%,
      rgb(109.7, 52.76, 239.32) 75.73%,
      rgb(115.82, 109.96, 213.48) 100%
    );
    filter: blur(12px);
    height: 308px;
    left: 64px;
    position: absolute;
    top: 64px;
    transform: rotate(45deg);
    width: 308px;
  }

  .rectangle-11 {
    background: linear-gradient(
      180deg,
      rgb(255, 255, 255) 0%,
      rgb(239, 68, 68) 39.83%,
      rgb(109.7, 52.76, 239.32) 75.73%,
      rgb(115.82, 109.96, 213.48) 100%
    );
    filter: blur(64px);
    height: 308px;
    left: 64px;
    position: absolute;
    top: 64px;
    transform: rotate(45deg);
    width: 308px;
  }

  .rectangle-12 {
    background: linear-gradient(
      180deg,
      rgb(255, 255, 255) 0%,
      rgb(239, 68, 68) 39.83%,
      rgb(109.7, 52.76, 239.32) 75.73%,
      rgb(115.82, 109.96, 213.48) 100%
    );
    filter: blur(120px);
    height: 308px;
    left: 64px;
    position: absolute;
    top: 64px;
    transform: rotate(45deg);
    width: 308px;
  }

  .rectangle-13 {
    background-color: #0f0f0f;
    box-shadow: inset 0px 4px 32px #ffffff40;
    height: 308px;
    left: 64px;
    position: absolute;
    top: 64px;
    transform: rotate(45deg);
    width: 308px;
  }

  .frame-20 {
    border-radius: 16px;
    height: 3px;
    left: 2713px;
    position: absolute;
    top: 3365px;
    width: 1328px;
  }

  .from-to-millions {
    color: #ffffff;
    font-family: "Poppins", Helvetica;
    font-size: 42px;
    font-weight: 500;
    height: 118px;
    left: 550px;
    letter-spacing: -2px;
    line-height: 44.5px;
    position: absolute;
    text-align: center;
    top: 425px;
    width: 711px;
  }

  .in-the-fiat-world {
    color: transparent;
    font-family: "Poppins", Helvetica;
    font-size: 29px;
    font-weight: 400;
    height: 213px;
    left: 17px;
    letter-spacing: -2px;
    line-height: 30.7px;
    position: absolute;
    text-align: center;
    top: -475px;
    width: 1311px;
  }

  .text-wrapper-28 {
    color: #ffffff;
    font-weight: 500;
    letter-spacing: -0.58px;
  }

  .text-wrapper-29 {
    color: #b0b0b0;
    font-weight: 500;
    letter-spacing: -0.58px;
  }

  .text-wrapper-30 {
    color: #d2ff3a;
    font-family: "Akisa-Regular", Helvetica;
    letter-spacing: -0.58px;
  }

  .text-wrapper-31 {
    color: #d2ff3a;
    font-weight: 500;
    letter-spacing: -0.58px;
  }

  .group-16 {
    height: 56px;
    left: 3271px;
    position: absolute;
    top: 8457px;
    width: 212px;
  }

  .ASK-THEO-wrapper {
    -webkit-backdrop-filter: blur(50px) brightness(100%);
    backdrop-filter: blur(50px) brightness(100%);
    background-color: #d2ff3a;
    border-radius: 40px;
    height: 56px;
    left: 0;
    position: absolute;
    top: 0;
    width: 145px;
  }

  .ASK-THEO {
    color: #1f1f1f;
    font-family: "Poppins", Helvetica;
    font-size: 16px;
    font-weight: 600;
    left: 32px;
    letter-spacing: 0.48px;
    line-height: normal;
    position: absolute;
    top: 16px;
  }

  .vector-wrapper {
    background-color: #ef3333;
    border-radius: 28px;
    height: 56px;
    left: 156px;
    position: absolute;
    top: 0;
    width: 56px;
  }

  .vector {
    height: 32px;
    left: 3px;
    position: absolute;
    top: 8px;
    width: 24px;
  }

  .overlap-12 {
    height: 541px;
    left: 2706px;
    position: absolute;
    top: 4656px;
    width: 1330px;
  }

  .frame-21 {
    background-color: #ef3333;
    border-radius: 16px;
    box-shadow: 0px 4px 43px #feb5b5;
    height: 373px;
    left: 548px;
    position: absolute;
    top: 45px;
    width: 674px;
  }

  .map {
    height: 541px;
    left: 368px;
    object-fit: cover;
    position: absolute;
    top: 0;
    width: 962px;
  }

  .frame-22 {
    height: 117px;
    left: 0;
    position: absolute;
    top: 218px;
    width: 574px;
  }

  .accessible-to {
    color: #f5f5f5;
    font-family: "Poppins", Helvetica;
    font-size: 64px;
    font-weight: 600;
    height: 45px;
    left: 0;
    letter-spacing: -2px;
    line-height: 57.6px;
    position: absolute;
    text-shadow: 0px 2px 1px #00000026;
    top: -1px;
    white-space: nowrap;
  }

  .text-wrapper-32 {
    color: #f5f5f5;
    font-family: "Poppins", Helvetica;
    font-size: 64px;
    font-weight: 600;
    height: 45px;
    left: 0;
    letter-spacing: -2px;
    line-height: 57.6px;
    opacity: 0.7;
    position: absolute;
    top: 71px;
    white-space: nowrap;
  }

  .overlap-13 {
    height: 656px;
    left: 117px;
    position: absolute;
    top: 1975px;
    width: 1323px;
  }

  .overlap-14 {
    height: 656px;
    left: 0;
    position: absolute;
    top: 0;
    width: 1323px;
  }

  .group-17 {
    height: 470px;
    left: 999px;
    position: absolute;
    top: 186px;
    width: 324px;
  }

  .frame-23 {
    background-color: #ef3333;
    border-radius: 16px;
    box-shadow: 0px 4px 43px #feb5b5;
    height: 373px;
    left: 482px;
    position: absolute;
    top: 39px;
    width: 674px;
  }

  .map-2 {
    height: 541px;
    left: 347px;
    object-fit: cover;
    position: absolute;
    top: 0;
    width: 962px;
  }

  .accessible-to-2 {
    color: transparent;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 63px;
    font-weight: 400;
    height: 101px;
    left: 0;
    letter-spacing: -2px;
    line-height: 56.7px;
    position: absolute;
    text-shadow: 0px 2px 1px #00000026;
    top: 197px;
    width: 396px;
  }

  .text-wrapper-33 {
    color: #ffffff;
    letter-spacing: -1.26px;
  }

  .text-wrapper-34 {
    color: #b0b0b0;
    letter-spacing: -1.26px;
  }

  .from-to-millions-2 {
    color: transparent;
    font-family: "Poppins", Helvetica;
    font-size: 30px;
    font-weight: 600;
    height: 118px;
    left: 456px;
    letter-spacing: -2px;
    line-height: 31.8px;
    position: absolute;
    text-align: center;
    top: 461px;
    width: 711px;
  }

  .text-wrapper-35 {
    color: #ffffff;
    letter-spacing: -0.6px;
  }

  .text-wrapper-36 {
    color: #b0b0b0;
    letter-spacing: -0.6px;
  }

  .component-23 {
    left: 0 !important;
    position: absolute !important;
    top: 329px !important;
  }

  .why-choose-agent-2 {
    color: transparent;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 64px;
    font-weight: 400;
    height: 45px;
    left: 2930px;
    letter-spacing: -2px;
    line-height: 57.6px;
    position: absolute;
    text-align: center;
    text-shadow: 0px 2px 1px #00000026;
    top: 4500px;
    width: 812px;
  }

  .text-wrapper-37 {
    color: #ffffff;
    letter-spacing: -1.28px;
  }

  .text-wrapper-38 {
    color: #d2ff3a;
    letter-spacing: -1.28px;
  }

  .text-wrapper-39 {
    color: #d2ff3a;
    font-family: "Akisa-Regular", Helvetica;
    letter-spacing: -1.28px;
  }

  .the-power-of-a-money {
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 40px;
    font-weight: 400;
    height: 28px;
    left: 3013px;
    letter-spacing: -2px;
    line-height: 36px;
    position: absolute;
    text-align: center;
    text-shadow: 0px 2px 1px #00000026;
    top: 4584px;
    white-space: nowrap;
  }

  .AI-drive-precision {
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 50px;
    font-weight: 400;
    height: 35px;
    left: -2005px;
    letter-spacing: -2px;
    line-height: 45px;
    position: absolute;
    text-align: center;
    text-shadow: 0px 2px 1px #00000026;
    top: 3067px;
    width: 358px;
  }

  .overlap-15 {
    height: 624px;
    left: 103px;
    position: absolute;
    top: 3462px;
    width: 1277px;
  }

  .overlap-16 {
    height: 624px;
    left: 540px;
    position: absolute;
    top: 0;
    width: 737px;
  }

  .cvuvmawu {
    height: 624px;
    left: 113px;
    position: absolute;
    top: 0;
    width: 624px;
  }

  .component-78-wrapper {
    height: 44px;
    left: 0;
    position: absolute;
    top: 51px;
    width: 146px;
  }

  .component-24 {
    width: unset !important;
  }

  .frame-24 {
    align-items: flex-start;
    display: flex;
    flex-direction: column;
    gap: 58px;
    left: 0;
    position: absolute;
    top: 285px;
    width: 590px;
  }

  .secure-private {
    align-self: stretch;
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 63px;
    font-weight: 400;
    height: 32px;
    letter-spacing: -2px;
    line-height: 56.7px;
    margin-top: -1px;
    position: relative;
    text-shadow: 0px 2px 1px #00000026;
    white-space: nowrap;
  }

  .no-private-key {
    align-self: stretch;
    color: transparent;
    font-family: "Poppins", Helvetica;
    font-size: 37px;
    font-weight: 500;
    height: 51px;
    letter-spacing: -2px;
    line-height: 42.5px;
    position: relative;
    text-shadow: 0px 2px 1px #00000026;
    white-space: nowrap;
  }

  .text-wrapper-40 {
    color: #ffffff;
    letter-spacing: -0.74px;
  }

  .text-wrapper-41 {
    color: #b0b0b0;
    letter-spacing: -0.74px;
  }

  .unlike-human {
    color: transparent;
    font-family: "Poppins", Helvetica;
    font-size: 37px;
    font-weight: 500;
    height: 69px;
    left: 175px;
    letter-spacing: -2px;
    line-height: 42.5px;
    position: absolute;
    text-align: center;
    text-shadow: 0px 2px 1px #00000026;
    top: 4923px;
    width: 1089px;
  }

  .text-wrapper-42 {
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 16px;
    font-weight: 400;
    left: 118px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 6634px;
    white-space: nowrap;
  }

  .text-wrapper-43 {
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 16px;
    font-weight: 400;
    left: 207px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 6634px;
    white-space: nowrap;
  }

  .text-wrapper-44 {
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 16px;
    font-weight: 400;
    left: 285px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 6634px;
    white-space: nowrap;
  }

  .text-wrapper-45 {
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 16px;
    font-weight: 400;
    left: 412px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 6634px;
    white-space: nowrap;
  }

  .text-wrapper-46 {
    color: #ffffffb2;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 16px;
    font-weight: 400;
    left: 1164px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 6634px;
    white-space: nowrap;
  }

  .overlap-17 {
    height: 1123px;
    left: 0;
    position: absolute;
    top: 0;
    width: 1889px;
  }

  .frame-25 {
    height: 347px;
    left: 126px;
    position: absolute;
    top: 776px;
    width: 1188px;
  }

  .theo-red-3 {
    height: 93px;
    left: 688px;
    object-fit: cover;
    position: absolute;
    top: 1162px;
    width: 93px;
  }

  .introducing-agent {
    color: transparent;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 64px;
    font-weight: 400;
    height: 45px;
    left: 322px;
    letter-spacing: -2px;
    line-height: 57.6px;
    position: absolute;
    text-align: center;
    text-shadow: 0px 2px 1px #00000026;
    top: 1342px;
    width: 812px;
  }

  .text-wrapper-47 {
    color: #ef3333;
    font-family: "Akisa-Regular", Helvetica;
    letter-spacing: -1.28px;
  }

  .in-the-fiat-world-2 {
    color: #b0b0b0;
    font-family: "Poppins", Helvetica;
    font-size: 29px;
    font-weight: 500;
    height: 286px;
    left: 87px;
    letter-spacing: -2px;
    line-height: 30.7px;
    position: absolute;
    text-align: center;
    top: 1436px;
    width: 1311px;
  }

  .frame-wrapper {
    height: 45px;
    left: 521px;
    position: absolute;
    top: 4144px;
    width: 496px;
  }

  .frame-26 {
    height: 45px;
    position: relative;
  }

  .text-wrapper-48 {
    color: #f5f5f5;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 64px;
    font-weight: 400;
    height: 45px;
    left: 83px;
    letter-spacing: -2px;
    line-height: 57.6px;
    position: absolute;
    text-align: center;
    text-shadow: 0px 2px 1px #00000026;
    top: -1px;
    white-space: nowrap;
  }

  .x {
    height: 48px;
    left: 1283px;
    position: absolute;
    top: 6616px;
    width: 31px;
  }

  .linked-in {
    height: 48px;
    left: 1323px;
    position: absolute;
    top: 6616px;
    width: 31px;
  }

  .discord-new {
    height: 48px;
    left: 1363px;
    position: absolute;
    top: 6616px;
    width: 31px;
  }
`;

export const Desktop = () => {
  return (
    <StyledDesktop>
      <div className="div-2">
        <div className="overlap-7">
          <div className="group-10">
            <div className="overlap-8">
              <div className="glow-radial">
                <div className="overlap-group-6">
                  <img
                    className="ellipse-blur"
                    alt="Ellipse blur"
                    src="/img/ellipse-blur-1.svg"
                  />

                  <img
                    className="ellipse-blur"
                    alt="Ellipse blur"
                    src="/img/ellipse-blur-2.svg"
                  />

                  <img
                    className="ellipse-blur"
                    alt="Ellipse blur"
                    src="/img/ellipse-blur-3.svg"
                  />

                  <img
                    className="ellipse-blur"
                    alt="Ellipse blur"
                    src="/img/ellipse-blur-4.svg"
                  />
                </div>
              </div>

              <div className="ellipse-3" />

              <img
                className="ellipse-4"
                alt="Ellipse"
                src="/img/ellipse-62.svg"
              />

              <img
                className="ellipse-5"
                alt="Ellipse"
                src="/img/ellipse-63.svg"
              />
            </div>
          </div>

          <div className="frame-6">
            <img
              className="ellipse-6"
              alt="Ellipse"
              src="/img/ellipse-19.png"
            />

            <div className="ellipse-7" />
          </div>

          <div className="frame-7">
            <img
              className="ellipse-6"
              alt="Ellipse"
              src="/img/ellipse-19-1.png"
            />

            <div className="ellipse-7" />
          </div>

          <div className="frame-8">
            <img
              className="ellipse-8"
              alt="Ellipse"
              src="/img/ellipse-19-2.png"
            />

            <div className="frame-9">
              <p className="text-wrapper-15">
                “Theo helped me increase my portfolio ROI by 35%!”
              </p>

              <div className="text-wrapper-16">Mark, Professional Trader.</div>
            </div>
          </div>

          <div className="frame-10">
            <img
              className="ellipse-8"
              alt="Ellipse"
              src="/img/ellipse-19-3.png"
            />

            <div className="frame-11">
              <p className="text-wrapper-15">Theo is The best, love it!🔥</p>

              <div className="text-wrapper-16">Hina</div>
            </div>
          </div>

          <div className="frame-12">
            <img
              className="ellipse-8"
              alt="Ellipse"
              src="/img/ellipse-19-4.png"
            />

            <div className="frame-13">
              <div className="text-wrapper-15">Highly Recommended!</div>

              <div className="text-wrapper-16">Sarah</div>
            </div>
          </div>

          <div className="frame-14">
            <img
              className="ellipse-9"
              alt="Ellipse"
              src="/img/ellipse-20.png"
            />

            <div className="frame-15">
              <p className="i-finally-trade-with">
                “I finally trade with confidence,
                <br />
                thanks to Theo’s risk management tools.”
              </p>

              <div className="text-wrapper-17">Louis Patridge</div>
            </div>
          </div>

          <div className="text-wrapper-18">Testimonials</div>

          <Component80
            className="component-80-instance"
            property1="frame-2147223995"
          />
          <div className="frame-16">
            <img
              className="ellipse-6"
              alt="Ellipse"
              src="/img/ellipse-19-5.png"
            />

            <div className="ellipse-7" />
          </div>

          <div className="frame-17">
            <img
              className="ellipse-6"
              alt="Ellipse"
              src="/img/ellipse-19-6.png"
            />

            <div className="ellipse-7" />
          </div>

          <div className="rectangle-6" />

          <div className="frequently-asked">
            Frequently Asked &amp; <br />
            Question
          </div>

          <p className="get-smarter-with">
            Get Smarter with Theo –<br />
            Start Your Journey Today!
          </p>

          <p className="text-wrapper-19">Free trial with no commitment.</p>

          <p className="text-wrapper-20">Explore Theo’s features in detail.</p>

          <div className="rectangle-7" />

          <div className="rectangle-8" />

          <div className="rectangle-9" />

          <p className="text-wrapper-21">Is Theo safe to use?</p>

          <div className="text-wrapper-22">Can beginners use Theo?</div>

          <p className="text-wrapper-23">
            Free to start, with premium options for advanced features (coming
            soon)
          </p>

          <p className="text-wrapper-24">How much does it cost?</p>

          <div className="group-11">
            <div className="overlap-9">
              <div className="ellipse-10" />

              <img
                className="ep-arrow-left-bold"
                alt="Ep arrow left bold"
                src="/img/ep-arrow-left-bold-1.svg"
              />
            </div>
          </div>

          <div className="group-12">
            <div className="overlap-9">
              <div className="ellipse-10" />

              <img
                className="ep-arrow-left-bold"
                alt="Ep arrow left bold"
                src="/img/ep-arrow-left-bold-1.svg"
              />
            </div>
          </div>

          <div className="group-13">
            <div className="overlap-9">
              <div className="ellipse-11" />

              <img
                className="ep-arrow-left-bold"
                alt="Ep arrow left bold"
                src="/img/ep-arrow-left-bold-2.svg"
              />
            </div>
          </div>

          <PropertyFrameWrapper
            className="component-21"
            property1="frame-2147223995"
            text="JOIN NOW"
          />
          <div className="component-22">
            <div className="overlap-10">
              <div className="group-14">
                <div className="overlap-group-7">
                  <div className="TRY-THEO-2">LEARN MORE</div>
                </div>
              </div>

              <img
                className="lucide-arrow-up-3"
                alt="Lucide arrow up"
                src="/img/lucide-arrow-up-2.svg"
              />
            </div>
          </div>
        </div>

        <p className="why-choose-agent">
          <span className="span">Why Choose Agent </span>

          <span className="text-wrapper-25">Theo?</span>

          <span className="text-wrapper-26">&nbsp;</span>
        </p>

        <div className="text-wrapper-27">AI Driven Precision</div>

        <p className="the-power-OF-a-money">
          The Power Of A Money Manager For All
        </p>

        <div className="frame-18">
          <img
            className="frame-19"
            alt="Frame"
            src="/img/frame-2147223931.svg"
          />

          <div className="overlap-11">
            <div className="group-15">
              <div className="overlap-group-8">
                <div className="rectangle-10" />

                <div className="rectangle-11" />

                <div className="rectangle-12" />
              </div>
            </div>

            <div className="rectangle-13" />
          </div>
        </div>

        <div className="frame-20">
          <p className="from-to-millions">
            From $100 To Millions, Theo Works For Investors Of All Levels.
          </p>

          <p className="in-the-fiat-world">
            <span className="text-wrapper-28">In</span>

            <span className="text-wrapper-29"> t</span>

            <span className="text-wrapper-28">he fiat world</span>

            <span className="text-wrapper-29">
              , only the ultra-wealthy can afford portfolio managers—experts who
              manage their investments, make decisions on their behalf, and
              drive their wealth forward. But what if everyone could have such a
              powerful money manager?
              <br />
              With{" "}
            </span>

            <span className="text-wrapper-30">Agent Theo</span>

            <span className="text-wrapper-31">,</span>

            <span className="text-wrapper-29">
              {" "}
              you can. Whether you’re investing a few hundred dollars or
              managing millions, Theo is your AI-powered money
              manager—affordable, accessible, and built to grow with you.
              <br />
            </span>
          </p>
        </div>

        <div className="group-16">
          <div className="ASK-THEO-wrapper">
            <div className="ASK-THEO">Ask Theo</div>
          </div>

          <div className="vector-wrapper">
            <img className="vector" alt="Vector" src="/img/vector.svg" />
          </div>
        </div>

        <div className="overlap-12">
          <div className="frame-21" />

          <img className="map" alt="Map" src="/img/map-100-00187-2.png" />

          <div className="frame-22">
            <div className="accessible-to">Accessible To</div>

            <div className="text-wrapper-32">Everyone</div>
          </div>
        </div>

        <div className="overlap-13">
          <div className="overlap-14">
            <img
              className="group-17"
              alt="Group"
              src="/img/group-1000002138.png"
            />

            <div className="frame-23" />

            <img className="map-2" alt="Map" src="/img/map-100-00187-3.png" />

            <p className="accessible-to-2">
              <span className="text-wrapper-33">Accessible to </span>

              <span className="text-wrapper-34">Everyone</span>
            </p>

            <p className="from-to-millions-2">
              <span className="text-wrapper-35">From $100 to millions, </span>

              <span className="text-wrapper-36">
                Theo works for investors of all levels.
              </span>
            </p>
          </div>

          <Component80 className="component-23" property1="frame-2147223995" />
        </div>

        <p className="why-choose-agent-2">
          <span className="text-wrapper-37">Why Choose Agent</span>

          <span className="text-wrapper-38">&nbsp;</span>

          <span className="text-wrapper-39">Theo ?</span>
        </p>

        <p className="the-power-of-a-money">
          The Power Of A Money Manager For All
        </p>

        <div className="AI-drive-precision">Ai-drive Precision</div>

        <div className="overlap-15">
          <div className="overlap-16">
            <img
              className="cvuvmawu"
              alt="Cvuvmawu"
              src="/img/cv2uvma6wu-3-1.gif"
            />

            <div className="component-78-wrapper">
              <PropertyFrameWrapper
                className="component-24"
                property1="frame-2147223995"
                text="TRY THEO"
              />
            </div>
          </div>

          <div className="frame-24">
            <div className="secure-private">Secure &amp; Private</div>

            <p className="no-private-key">
              <span className="text-wrapper-40">No private key </span>

              <span className="text-wrapper-41">
                sharing, fully decentralized, &amp; transparent.
              </span>
            </p>
          </div>
        </div>

        <p className="unlike-human">
          <span className="text-wrapper-40">Unlike human </span>

          <span className="text-wrapper-41">
            managers, Theo never sleeps—monitoring markets and seizing
            opportunities round-the-clock.
          </span>
        </p>

        <div className="text-wrapper-42">Features</div>

        <div className="text-wrapper-43">Pricing</div>

        <div className="text-wrapper-44">Privacy Policy</div>

        <div className="text-wrapper-45">Terms of Service</div>

        <div className="text-wrapper-46">© 2025, Theo</div>

        <div className="overlap-17">
          <FrameByAnima />
          <img
            className="frame-25"
            alt="Frame"
            src="/img/frame-1000006745.svg"
          />
        </div>

        <img className="theo-red-3" alt="Theo red" src="/img/theo-red-2.png" />

        <p className="introducing-agent">
          <span className="text-wrapper-37">Introducing Agent</span>

          <span className="text-wrapper-38">&nbsp;</span>

          <span className="text-wrapper-47">Theo</span>
        </p>

        <p className="in-the-fiat-world-2">
          In The Fiat World, Only The Ultra-wealthy Can Afford Portfolio
          Managers—experts Who Manage Their Investments, Make Decisions On Their
          Behalf, And Drive Their Wealth Forward. But What If Everyone Could
          Have Such A Powerful Money Manager?
          <br />
          <br />
          with Agent Theo You Can. Whether You’re Investing A Few Hundred
          Dollars Or Managing Millions, Theo Is Your Ai-powered Money
          Manager—affordable, Accessible, And Built To Grow With You.
        </p>

        <div className="frame-wrapper">
          <div className="frame-26">
            <div className="text-wrapper-48">24/7 Trading</div>
          </div>
        </div>

        <FrameWrapperByAnima />
        <ComponentByAnima />
        <img className="x" alt="X" src="/img/x.png" />

        <img className="linked-in" alt="Linked in" src="/img/linkedin.png" />

        <img
          className="discord-new"
          alt="Discord new"
          src="/img/discord-new.png"
        />
      </div>
    </StyledDesktop>
  );
};
