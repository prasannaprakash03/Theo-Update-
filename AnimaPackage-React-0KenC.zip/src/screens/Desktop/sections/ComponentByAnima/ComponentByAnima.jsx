import React from "react";
import styled from "styled-components";

const StyledComponentByAnima = styled.div`
  background-color: #000000;
  height: 564px;
  left: 194px;
  position: absolute;
  top: 4275px;
  width: 1115px;

  .overlap-2 {
    height: 564px;
    position: relative;
  }

  .group-5 {
    height: 564px;
    left: 481px;
    position: absolute;
    top: 0;
    width: 634px;
  }

  .group-6 {
    height: 563px;
    left: 0;
    position: absolute;
    top: 0;
    width: 803px;
  }

  .element {
    color: #ff0000;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 55px;
    font-weight: 400;
    height: 39px;
    left: 55px;
    letter-spacing: -2.00px;
    line-height: 49.5px;
    position: absolute;
    text-align: center;
    text-shadow: 0px 2px 1px #00000026;
    top: 486px;
    white-space: nowrap;
  }

  .element-am {
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 55px;
    font-weight: 400;
    height: 39px;
    left: 937px;
    letter-spacing: -2.00px;
    line-height: 49.5px;
    position: absolute;
    text-align: center;
    text-shadow: 0px 2px 1px #00000026;
    top: 476px;
    white-space: nowrap;
  }

  .overlap-wrapper {
    height: 232px;
    left: 339px;
    position: absolute;
    top: 168px;
    width: 439px;
  }

  .overlap-3 {
    height: 232px;
    position: relative;
    width: 447px;
  }

  .rectangle-5 {
    height: 232px;
    left: 0;
    position: absolute;
    top: 0;
    width: 437px;
  }

  .text-wrapper-6 {
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 20.3px;
    font-weight: 400;
    left: 30px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 29px;
    white-space: nowrap;
  }

  .element-2 {
    height: 66px;
    left: 0;
    position: absolute;
    top: 69px;
    width: 447px;
  }

  .overlap-group-3 {
    background-image: url(../../../../../static/img/rectangle-1.svg);
    background-size: 100% 100%;
    height: 66px;
    position: relative;
    width: 437px;
  }

  .text-wrapper-7 {
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 14.2px;
    font-weight: 400;
    left: 68px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 12px;
    white-space: nowrap;
  }

  .text-wrapper-8 {
    color: #25ac44;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 14.2px;
    font-weight: 400;
    left: 348px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 12px;
    white-space: nowrap;
  }

  .text-wrapper-9 {
    color: #ffffff99;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 12.2px;
    font-weight: 400;
    left: 363px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 41px;
    white-space: nowrap;
  }

  .text-wrapper-10 {
    color: #ffffff99;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 12.2px;
    font-weight: 400;
    left: 89px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 41px;
    white-space: nowrap;
  }

  .text-wrapper-11 {
    color: #ffffff99;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 12.2px;
    font-weight: 400;
    left: 131px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 41px;
    white-space: nowrap;
  }

  .path {
    height: 6px;
    left: 68px;
    position: absolute;
    top: 45px;
    width: 11px;
  }

  .element-3 {
    height: 66px;
    left: 0;
    position: absolute;
    top: 149px;
    width: 447px;
  }

  .overlap-4 {
    background-image: url(../../../../../static/img/rectangle-2.svg);
    background-size: 100% 100%;
    height: 66px;
    position: relative;
    width: 437px;
  }

  .text-wrapper-12 {
    color: #25ac44;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 14.2px;
    font-weight: 400;
    left: 352px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 15px;
    white-space: nowrap;
  }

  .mask-group-2 {
    height: 32px;
    left: 21px;
    position: absolute;
    top: 161px;
    width: 32px;
  }

  .mask-group-3 {
    height: 30px;
    left: 24px;
    position: absolute;
    top: 85px;
    width: 30px;
  }

  .theo-red-2 {
    height: 24px;
    left: 398px;
    object-fit: cover;
    position: absolute;
    top: 12px;
    width: 24px;
  }

  .group-wrapper {
    height: 34px;
    left: 507px;
    position: absolute;
    top: 422px;
    width: 100px;
  }

  .group-7 {
    height: 34px;
    width: 102px;
  }

  .overlap-group-4 {
    background-color: #ff0000;
    border-radius: 17px;
    height: 34px;
    position: relative;
    width: 100px;
  }

  .text-wrapper-13 {
    color: #ffffff;
    font-family: "Poppins", Helvetica;
    font-size: 16px;
    font-weight: 400;
    left: 18px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 4px;
  }
`;

export const ComponentByAnima = () => {
  return (
    <StyledComponentByAnima>
      <div className="overlap-2">
        <img className="group-5" alt="Group" src="/img/group-1000002129.png" />
        <img className="group-6" alt="Group" src="/img/group-1000002128.png" />
        <div className="element">12pm</div>
        <div className="element-am">12am</div>
        <div className="overlap-wrapper">
          <div className="overlap-3">
            <img
              className="rectangle-5"
              alt="Rectangle"
              src="/img/rectangle.svg"
            />
            <div className="text-wrapper-6">Agent Theo Trading</div>
            <div className="element-2">
              <div className="overlap-group-3">
                <div className="text-wrapper-7">BTC/USD</div>
                <div className="text-wrapper-8">$91210.18</div>
                <div className="text-wrapper-9">$140,99</div>
                <div className="text-wrapper-10">09.30</div>
                <div className="text-wrapper-11">27 FEB</div>
                <img className="path" alt="Path" src="/img/path.svg" />
              </div>
            </div>
            <div className="element-3">
              <div className="overlap-4">
                <div className="text-wrapper-7">ETH/USD</div>
                <div className="text-wrapper-12">$1.230.18</div>
                <div className="text-wrapper-9">$820,99</div>
                <div className="text-wrapper-10">08.50</div>
                <div className="text-wrapper-11">27 FEB</div>
                <img className="path" alt="Path" src="/img/path-1.svg" />
              </div>
            </div>
            <img
              className="mask-group-2"
              alt="Mask group"
              src="/img/mask-group-1.png"
            />
            <img
              className="mask-group-3"
              alt="Mask group"
              src="/img/mask-group-2.png"
            />
            <img
              className="theo-red-2"
              alt="Theo red"
              src="/img/theo-red-2-1.png"
            />
          </div>
        </div>
        <div className="group-wrapper">
          <div className="group-7">
            <div className="overlap-group-4">
              <div className="text-wrapper-13">AI Trade</div>
            </div>
          </div>
        </div>
      </div>
    </StyledComponentByAnima>
  );
};
