module.exports = {
  publicPath: "./",
};
