<template>
  <div :class="['property-wrapper', className]">
    <div :class="['title', titleClassName]">
      <img
        :class="['ETH', ETHClassName]"
        alt="Eth"
        :src="getImageSrc"
      />
      <div :class="['ETH-USD', property1, divClassName]">
        <span v-if="property1 === 'six'">ETH/USD</span>
        <span v-if="property1 === 'five'">SOl/USD</span>
        <span v-if="property1 === 'four'">LUNA/USD</span>
        <span v-if="property1 === 'three'">{{ text }}</span>
        <span v-if="property1 === 'two'">{{ text1 }}</span>
        <span v-if="property1 === 'one'">DOGE/USD</span>
      </div>
    </div>
    <div :class="['element-wrapper', frameClassName]">
      <div :class="['element-4', divClassNameOverride]">
        <span v-if="property1 === 'six'">75%</span>
        <span v-if="property1 === 'five'">25%</span>
        <span v-if="property1 === 'four'">15%</span>
        <span v-if="property1 === 'three'">68%</span>
        <span v-if="['one', 'two'].includes(property1)">{{ text2 }}</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "PropertyWrapper",
  props: {
    property1: {
      type: String,
      validator: function (value) {
        return ["two", "three", "four", "one", "five", "six"].indexOf(value) !== -1;
      },
    },
    tether: {
      type: String,
      default: "/img/tether.svg",
    },
    text: {
      type: String,
      default: "USDT/USD",
    },
    uniswap: {
      type: String,
      default: "/img/uniswap.svg",
    },
    text1: {
      type: String,
      default: "UNI/USD",
    },
    text2: {
      type: String,
      default: "45%",
    },
    LUNA: {
      type: String,
      default: "/img/luna.svg",
    },
    ETH: {
      type: String,
      default: "/img/eth.svg",
    },
    doge: {
      type: String,
      default: "/img/doge.svg",
    },
    solana: {
      type: String,
      default: "/img/solana.svg",
    },
    className: {
      type: String,
      default: "",
    },
    titleClassName: {
      type: String,
      default: "",
    },
    ETHClassName: {
      type: String,
      default: "",
    },
    divClassName: {
      type: String,
      default: "",
    },
    frameClassName: {
      type: String,
      default: "",
    },
    divClassNameOverride: {
      type: String,
      default: "",
    },
  },
  computed: {
    getImageSrc() {
      if (this.property1 === "five") return this.solana;
      if (this.property1 === "four") return this.LUNA;
      if (this.property1 === "three") return this.tether;
      if (this.property1 === "two") return this.uniswap;
      if (this.property1 === "one") return this.doge;
      return this.ETH;
    },
  },
};
</script>

<style>
.property-wrapper {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 16px;
  justify-content: center;
  position: relative;
  width: 180px;
}

.property-wrapper .title {
  align-items: center;
  align-self: stretch;
  display: flex;
  flex: 0 0 auto;
  gap: 6px;
  position: relative;
  width: 100%;
}

.property-wrapper .ETH {
  height: 24px;
  position: relative;
  width: 24px;
}

.property-wrapper .ETH-USD {
  color: #ffffff;
  font-family: "Outfit", Helvetica;
  font-size: 18px;
  font-weight: 500;
  letter-spacing: -0.72px;
  line-height: 25.2px;
  margin-top: -1.00px;
  position: relative;
}

.property-wrapper .element-wrapper {
  align-items: flex-start;
  background-color: #ffffff1a;
  border-radius: 32px;
  display: inline-flex;
  flex: 0 0 auto;
  gap: 8px;
  padding: 4px 8px;
  position: relative;
}

.property-wrapper .element-4 {
  color: #ffffff;
  font-family: "DM Sans", Helvetica;
  font-size: 14px;
  font-weight: 400;
  letter-spacing: 1.40px;
  line-height: 19.6px;
  margin-top: -1.00px;
  opacity: 0.7;
  position: relative;
  white-space: nowrap;
  width: fit-content;
}

.property-wrapper .two {
  white-space: nowrap;
  width: fit-content;
}

.property-wrapper .six {
  width: 150px;
}

.property-wrapper .four {
  width: 150px;
}

.property-wrapper .five {
  width: 150px;
}

.property-wrapper .one {
  white-space: nowrap;
  width: fit-content;
}

.property-wrapper .three {
  white-space: nowrap;
  width: fit-content;
}
</style>