<template>
  <div class="desktop">
    <div class="div-2">
      <div class="overlap-7">
        <div class="group-10">
          <div class="overlap-8">
            <div class="glow-radial">
              <div class="overlap-group-6">
                <img
                  class="ellipse-blur"
                  alt="Ellipse blur"
                  src="/img/ellipse-blur-1.svg"
                />
                <img
                  class="ellipse-blur"
                  alt="Ellipse blur"
                  src="/img/ellipse-blur-2.svg"
                />
                <img
                  class="ellipse-blur"
                  alt="Ellipse blur"
                  src="/img/ellipse-blur-3.svg"
                />
                <img
                  class="ellipse-blur"
                  alt="Ellipse blur"
                  src="/img/ellipse-blur-4.svg"
                />
              </div>
            </div>
            <div class="ellipse-3" />
            <img
              class="ellipse-4"
              alt="Ellipse"
              src="/img/ellipse-62.svg"
            />
            <img
              class="ellipse-5"
              alt="Ellipse"
              src="/img/ellipse-63.svg"
            />
          </div>
        </div>
        <div class="frame-6">
          <img
            class="ellipse-6"
            alt="Ellipse"
            src="/img/ellipse-19.png"
          />
          <div class="ellipse-7" />
        </div>
        <div class="frame-7">
          <img
            class="ellipse-6"
            alt="Ellipse"
            src="/img/ellipse-19-1.png"
          />
          <div class="ellipse-7" />
        </div>
        <div class="frame-8">
          <img
            class="ellipse-8"
            alt="Ellipse"
            src="/img/ellipse-19-2.png"
          />
          <div class="frame-9">
            <p class="text-wrapper-15">
              “Theo helped me increase my portfolio ROI by 35%!”
            </p>
            <div class="text-wrapper-16">Mark, Professional Trader.</div>
          </div>
        </div>
        <div class="frame-10">
          <img
            class="ellipse-8"
            alt="Ellipse"
            src="/img/ellipse-19-3.png"
          />
          <div class="frame-11">
            <p class="text-wrapper-15">Theo is The best, love it!🔥</p>
            <div class="text-wrapper-16">Hina</div>
          </div>
        </div>
        <div class="frame-12">
          <img
            class="ellipse-8"
            alt="Ellipse"
            src="/img/ellipse-19-4.png"
          />
          <div class="frame-13">
            <div class="text-wrapper-15">Highly Recommended!</div>
            <div class="text-wrapper-16">Sarah</div>
          </div>
        </div>
        <div class="frame-14">
          <img
            class="ellipse-9"
            alt="Ellipse"
            src="/img/ellipse-20.png"
          />
          <div class="frame-15">
            <p class="i-finally-trade-with">
              “I finally trade with confidence,
              <br />
              thanks to Theo’s risk management tools.”
            </p>
            <div class="text-wrapper-17">Louis Patridge</div>
          </div>
        </div>
        <div class="text-wrapper-18">Testimonials</div>
        <Component80
          class="component-80-instance"
          property1="frame-2147223995"
        />
        <div class="frame-16">
          <img
            class="ellipse-6"
            alt="Ellipse"
            src="/img/ellipse-19-5.png"
          />
          <div class="ellipse-7" />
        </div>
        <div class="frame-17">
          <img
            class="ellipse-6"
            alt="Ellipse"
            src="/img/ellipse-19-6.png"
          />
          <div class="ellipse-7" />
        </div>
        <div class="rectangle-6" />
        <div class="frequently-asked">
          Frequently Asked &amp; <br />
          Question
        </div>
        <p class="get-smarter-with">
          Get Smarter with Theo –<br />
          Start Your Journey Today!
        </p>
        <p class="text-wrapper-19">Free trial with no commitment.</p>
        <p class="text-wrapper-20">Explore Theo’s features in detail.</p>
        <div class="rectangle-7" />
        <div class="rectangle-8" />
        <div class="rectangle-9" />
        <p class="text-wrapper-21">Is Theo safe to use?</p>
        <div class="text-wrapper-22">Can beginners use Theo?</div>
        <p class="text-wrapper-23">
          Free to start, with premium options for advanced features (coming
          soon)
        </p>
        <p class="text-wrapper-24">How much does it cost?</p>
        <div class="group-11">
          <div class="overlap-9">
            <div class="ellipse-10" />
            <img
              class="ep-arrow-left-bold"
              alt="Ep arrow left bold"
              src="/img/ep-arrow-left-bold-1.svg"
            />
          </div>
        </div>
        <div class="group-12">
          <div class="overlap-9">
            <div class="ellipse-10" />
            <img
              class="ep-arrow-left-bold"
              alt="Ep arrow left bold"
              src="/img/ep-arrow-left-bold-1.svg"
            />
          </div>
        </div>
        <div class="group-13">
          <div class="overlap-9">
            <div class="ellipse-11" />
            <img
              class="ep-arrow-left-bold"
              alt="Ep arrow left bold"
              src="/img/ep-arrow-left-bold-2.svg"
            />
          </div>
        </div>
        <PropertyFrameWrapper
          class="component-21"
          property1="frame-2147223995"
          text="JOIN NOW"
        />
        <div class="component-22">
          <div class="overlap-10">
            <div class="group-14">
              <div class="overlap-group-7">
                <div class="TRY-THEO-2">LEARN MORE</div>
              </div>
            </div>
            <img
              class="lucide-arrow-up-3"
              alt="Lucide arrow up"
              src="/img/lucide-arrow-up-2.svg"
            />
          </div>
        </div>
      </div>
      <p class="why-choose-agent">
        <span class="span">Why Choose Agent </span>
        <span class="text-wrapper-25">Theo?</span>
        <span class="text-wrapper-26">&nbsp;</span>
      </p>
      <div class="text-wrapper-27">AI Driven Precision</div>
      <p class="the-power-OF-a-money">
        The Power Of A Money Manager For All
      </p>
      <div class="frame-18">
        <img
          class="frame-19"
          alt="Frame"
          src="/img/frame-2147223931.svg"
        />
        <div class="overlap-11">
          <div class="group-15">
            <div class="overlap-group-8">
              <div class="rectangle-10" />
              <div class="rectangle-11" />
              <div class="rectangle-12" />
            </div>
          </div>
          <div class="rectangle-13" />
        </div>
      </div>
      <div class="frame-20">
        <p class="from-to-millions">
          From $100 To Millions, Theo Works For Investors Of All Levels.
        </p>
        <p class="in-the-fiat-world">
          <span class="text-wrapper-28">In</span>
          <span class="text-wrapper-29"> t</span>
          <span class="text-wrapper-28">he fiat world</span>
          <span class="text-wrapper-29">
            , only the ultra-wealthy can afford portfolio managers—experts who
            manage their investments, make decisions on their behalf, and
            drive their wealth forward. But what if everyone could have such a
            powerful money manager?
            <br />
            With{" "}
          </span>
          <span class="text-wrapper-30">Agent Theo</span>
          <span class="text-wrapper-31">,</span>
          <span class="text-wrapper-29">
            {" "}
            you can. Whether you’re investing a few hundred dollars or
            managing millions, Theo is your AI-powered money
            manager—affordable, accessible, and built to grow with you.
            <br />
          </span>
        </p>
      </div>
      <div class="group-16">
        <div class="ASK-THEO-wrapper">
          <div class="ASK-THEO">Ask Theo</div>
        </div>
        <div class="vector-wrapper">
          <img class="vector" alt="Vector" src="/img/vector.svg" />
        </div>
      </div>
      <div class="overlap-12">
        <div class="frame-21" />
        <img class="map" alt="Map" src="/img/map-100-00187-2.png" />
        <div class="frame-22">
          <div class="accessible-to">Accessible To</div>
          <div class="text-wrapper-32">Everyone</div>
        </div>
      </div>
      <div class="overlap-13">
        <div class="overlap-14">
          <img
            class="group-17"
            alt="Group"
            src="/img/group-1000002138.png"
          />
          <div class="frame-23" />
          <img class="map-2" alt="Map" src="/img/map-100-00187-3.png" />
          <p class="accessible-to-2">
            <span class="text-wrapper-33">Accessible to </span>
            <span class="text-wrapper-34">Everyone</span>
          </p>
          <p class="from-to-millions-2">
            <span class="text-wrapper-35">From $100 to millions, </span>
            <span class="text-wrapper-36">
              Theo works for investors of all levels.
            </span>
          </p>
        </div>
        <Component80 class="component-23" property1="frame-2147223995" />
      </div>
      <p class="why-choose-agent-2">
        <span class="text-wrapper-37">Why Choose Agent</span>
        <span class="text-wrapper-38">&nbsp;</span>
        <span class="text-wrapper-39">Theo ?</span>
      </p>
      <p class="the-power-of-a-money">
        The Power Of A Money Manager For All
      </p>
      <div class="AI-drive-precision">Ai-drive Precision</div>
      <div class="overlap-15">
        <div class="overlap-16">
          <img
            class="cvuvmawu"
            alt="Cvuvmawu"
            src="/img/cvuvmawu-3-1.gif"
          />
          <div class="component-78-wrapper">
            <PropertyFrameWrapper
              class="component-24"
              property1="frame-2147223995"
              text="TRY THEO"
            />
          </div>
        </div>
        <div class="frame-24">
          <div class="secure-private">Secure &amp; Private</div>
          <p class="no-private-key">
            <span class="text-wrapper-40">No private key </span>
            <span class="text-wrapper-41">
              sharing, fully decentralized, &amp; transparent.
            </span>
          </p>
        </div>
      </div>
      <p class="unlike-human">
        <span class="text-wrapper-40">Unlike human </span>
        <span class="text-wrapper-41">
          managers, Theo never sleeps—monitoring markets and seizing
          opportunities round-the-clock.
        </span>
      </p>
      <div class="text-wrapper-42">Features</div>
      <div class="text-wrapper-43">Pricing</div>
      <div class="text-wrapper-44">Privacy Policy</div>
      <div class="text-wrapper-45">Terms of Service</div>
      <div class="text-wrapper-46">© 2025, Theo</div>
      <div class="overlap-17">
        <FrameByAnima />
        <img
          class="frame-25"
          alt="Frame"
          src="/img/frame-1000006745.svg"
        />
      </div>
      <img class="theo-red-3" alt="Theo red" src="/img/theo-red-2.png" />
      <p class="introducing-agent">
        <span class="text-wrapper-37">Introducing Agent</span>
        <span class="text-wrapper-38">&nbsp;</span>
        <span class="text-wrapper-47">Theo</span>
      </p>
      <p class="in-the-fiat-world-2">
        In The Fiat World, Only The Ultra-wealthy Can Afford Portfolio
        Managers—experts Who Manage Their Investments, Make Decisions On Their
        Behalf, And Drive Their Wealth Forward. But What If Everyone Could
        Have Such A Powerful Money Manager?
        <br />
        <br />
        with Agent Theo You Can. Whether You’re Investing A Few Hundred
        Dollars Or Managing Millions, Theo Is Your Ai-powered Money
        Manager—affordable, Accessible, And Built To Grow With You.
      </p>
      <div class="frame-wrapper">
        <div class="frame-26">
          <div class="text-wrapper-48">24/7 Trading</div>
        </div>
      </div>
      <FrameWrapperByAnima />
      <ComponentByAnima />
      <img class="x" alt="X" src="/img/x.png" />
      <img class="linked-in" alt="Linked in" src="/img/linkedin.png" />
      <img
        class="discord-new"
        alt="Discord new"
        src="/img/discord-new.png"
      />
    </div>
  </div>
</template>

<script>
import Component80 from "../components/Component80.vue";
import PropertyFrameWrapper from "../components/PropertyFrameWrapper.vue";
import ComponentByAnima from "./Desktop/sections/ComponentByAnima.vue";
import FrameByAnima from "./Desktop/sections/FrameByAnima.vue";
import FrameWrapperByAnima from "./Desktop/sections/FrameWrapperByAnima.vue";

export default {
  name: "Desktop",
  components: {
    Component80,
    PropertyFrameWrapper,
    ComponentByAnima,
    FrameByAnima,
    FrameWrapperByAnima,
  },
};
</script>

<style>
.desktop {
  background-color: #000000;
  display: flex;
  flex-direction: row;
  justify-content: center;
  width: 100%;
}

.desktop .div-2 {
  background-color: #000000;
  height: 6732px;
  overflow: hidden;
  position: relative;
  width: 1440px;
}

.desktop .overlap-7 {
  height: 1408px;
  left: 0;
  position: absolute;
  top: 5079px;
  width: 1440px;
}

.desktop .group-10 {
  background-image: url(../../static/img/ellipse-60.svg);
  background-size: 100% 100%;
  height: 1216px;
  left: 95px;
  position: absolute;
  top: 0;
  width: 1216px;
}

.desktop .overlap-8 {
  height: 1216px;
  position: relative;
}

.desktop .glow-radial {
  height: 1216px;
  left: 0;
  position: absolute;
  top: 0;
  width: 1216px;
}

.desktop .overlap-group-6 {
  background-image: url(../../static/img/ellipse-blur.svg);
  background-size: 100% 100%;
  height: 1296px;
  left: -40px;
  position: relative;
  top: -40px;
  width: 1296px;
}

.desktop .ellipse-blur {
  height: 1296px;
  left: 0;
  position: absolute;
  top: 0;
  width: 1296px;
}

.desktop .ellipse-3 {
  border: 1px solid;
  border-color: #ff2929;
  border-radius: 608px;
  height: 1216px;
  left: 0;
  position: absolute;
  top: 0;
  width: 1216px;
}

.desktop .ellipse-4 {
  height: 968px;
  left: 112px;
  position: absolute;
  top: 124px;
  width: 992px;
}

.desktop .ellipse-5 {
  height: 753px;
  left: 250px;
  position: absolute;
  top: 235px;
  width: 716px;
}

.desktop .frame-6 {
  height: 58px;
  left: 1029px;
  position: absolute;
  top: 642px;
  width: 45px;
}

.desktop .ellipse-6 {
  height: 45px;
  left: 0;
  object-fit: cover;
  position: absolute;
  top: 0;
  width: 45px;
}

.desktop .ellipse-7 {
  background-color: #d9d9d9;
  border-radius: 5px;
  height: 10px;
  left: 18px;
  position: absolute;
  top: 48px;
  width: 10px;
}

.desktop .frame-7 {
  height: 58px;
  left: 216px;
  position: absolute;
  top: 696px;
  width: 45px;
}

.desktop .frame-8 {
  background-color: #ff0000;
  border: 1px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(82.87, 64.47, 128.86), rgba(119, 103, 159, 0)) 1;
  border-radius: 99px;
  height: 69px;
  left: 773px;
  position: absolute;
  top: 89px;
  width: 520px;
}

.desktop .ellipse-8 {
  height: 45px;
  left: 12px;
  object-fit: cover;
  position: absolute;
  top: 12px;
  width: 45px;
}

.desktop .frame-9 {
  height: 37px;
  left: 69px;
  position: absolute;
  top: 16px;
  width: 427px;
}

.desktop .text-wrapper-15 {
  color: #ffffff;
  font-family: "Poppins", Helvetica;
  font-size: 16px;
  font-weight: 700;
  left: 0;
  letter-spacing: 0;
  line-height: 18px;
  position: absolute;
  top: -1px;
  white-space: nowrap;
}

.desktop .text-wrapper-16 {
  color: #ffffff;
  font-family: "Poppins", Helvetica;
  font-size: 16px;
  font-weight: 400;
  left: 0;
  letter-spacing: 0;
  line-height: normal;
  opacity: 0.7;
  position: absolute;
  top: 25px;
  white-space: nowrap;
}

.desktop .frame-10 {
  background-color: #ff0000;
  border: 1px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(82.87, 64.47, 128.86), rgba(119, 103, 159, 0)) 1;
  border-radius: 99px;
  height: 69px;
  left: 1078px;
  position: absolute;
  top: 416px;
  width: 304px;
}

.desktop .frame-11 {
  height: 41px;
  left: 69px;
  position: absolute;
  top: 14px;
  width: 211px;
}

.desktop .frame-12 {
  background-color: #ff0101;
  border: 1px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(82.87, 64.47, 128.86), rgba(119, 103, 159, 0)) 1;
  border-radius: 99px;
  height: 69px;
  left: 238px;
  position: absolute;
  top: 205px;
  width: 282px;
}

.desktop .frame-13 {
  height: 41px;
  left: 69px;
  position: absolute;
  top: 14px;
  width: 189px;
}

.desktop .frame-14 {
  background-color: #ff0000;
  border: 1px solid;
  border-color: transparent;
  border-image: linear-gradient(to bottom, rgb(82.87, 64.47, 128.86), rgba(119, 103, 159, 0)) 1;
  border-radius: 99px;
  height: 79px;
  left: 59px;
  position: absolute;
  top: 527px;
  width: 437px;
}

.desktop .ellipse-9 {
  height: 45px;
  left: 12px;
  object-fit: cover;
  position: absolute;
  top: 17px;
  width: 45px;
}

.desktop .frame-15 {
  height: 55px;
  left: 69px;
  position: absolute;
  top: 12px;
  width: 344px;
}

.desktop .i-finally-trade-with {
  color: #ffffff;
  font-family: "Poppins", Helvetica;
  font-size: 16px;
  font-weight: 700;
  left: 0;
  letter-spacing: 0;
  line-height: 18px;
  position: absolute;
  top: -1px;
}

.desktop .text-wrapper-17 {
  color: #ffffff;
  font-family: "Poppins", Helvetica;
  font-size: 16px;
  font-weight: 400;
  left: 0;
  letter-spacing: 0;
  line-height: normal;
  opacity: 0.7;
  position: absolute;
  top: 43px;
  white-space: nowrap;
}

.desktop .text-wrapper-18 {
  color: #ffffff;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 60px;
  font-weight: 400;
  left: 549px;
  letter-spacing: 0;
  line-height: 65px;
  position: absolute;
  text-align: center;
  top: 420px;
  white-space: nowrap;
}

.desktop .component-80-instance {
  left: 629px !important;
  position: absolute !important;
  top: 513px !important;
}

.desktop .frame-16 {
  height: 58px;
  left: 420px;
  position: absolute;
  top: 5px;
  width: 45px;
}

.desktop .frame-17 {
  height: 58px;
  left: 888px;
  position: absolute;
  top: 253px;
  width: 45px;
}

.desktop .rectangle-6 {
  background-color: #0f0f10;
  filter: blur(150px);
  height: 582px;
  left: 0;
  position: absolute;
  top: 779px;
  width: 1440px;
}

.desktop .frequently-asked {
  color: #ffffff;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 40px;
  font-weight: 400;
  left: 122px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 904px;
}

.desktop .get-smarter-with {
  color: #ffffff;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 40px;
  font-weight: 400;
  left: 889px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 896px;
}

.desktop .text-wrapper-19 {
  color: #ffffff;
  font-family: "Poppins", Helvetica;
  font-size: 27px;
  font-weight: 500;
  left: 889px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 1073px;
}

.desktop .text-wrapper-20 {
  color: #ffffff;
  font-family: "Poppins", Helvetica;
  font-size: 27px;
  font-weight: 500;
  left: 888px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 1217px;
}

.desktop .rectangle-7 {
  background-color: #ffffff;
  border: 1px solid;
  border-color: #b0b0b0;
  border-radius: 15px;
  height: 72px;
  left: 118px;
  position: absolute;
  top: 1057px;
  width: 672px;
}

.desktop .rectangle-8 {
  background-color: #ffffff;
  border: 1px solid;
  border-color: #b0b0b0;
  border-radius: 15px;
  height: 72px;
  left: 118px;
  position: absolute;
  top: 1336px;
  width: 672px;
}

.desktop .rectangle-9 {
  background-color: #ffffff;
  border: 1px solid;
  border-color: #b0b0b0;
  border-radius: 15px;
  height: 154px;
  left: 118px;
  position: absolute;
  top: 1150px;
  width: 672px;
}

.desktop .text-wrapper-21 {
  color: #000000;
  font-family: "Poppins", Helvetica;
  font-size: 20px;
  font-weight: 500;
  left: 142px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 1077px;
}

.desktop .text-wrapper-22 {
  color: #000000;
  font-family: "Poppins", Helvetica;
  font-size: 20px;
  font-weight: 500;
  left: 142px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 1356px;
}

.desktop .text-wrapper-23 {
  color: #000000;
  font-family: "Poppins", Helvetica;
  font-size: 16px;
  font-weight: 400;
  left: 140px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 1226px;
}

.desktop .text-wrapper-24 {
  color: #ef3333;
  font-family: "Poppins", Helvetica;
  font-size: 20px;
  font-weight: 500;
  left: 140px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 1178px;
}

.desktop .group-11 {
  height: 40px;
  left: 726px;
  position: absolute;
  top: 1073px;
  width: 40px;
}

.desktop .overlap-9 {
  border-radius: 20px;
  height: 40px;
  position: relative;
}

.desktop .ellipse-10 {
  background-color: #ffffff;
  border: 1px solid;
  border-color: #060548;
  border-radius: 20px;
  height: 40px;
  left: 0;
  position: absolute;
  top: 0;
  transform: rotate(180deg);
  width: 40px;
}

.desktop .ep-arrow-left-bold {
  height: 24px;
  left: 8px;
  position: absolute;
  top: 8px;
  width: 24px;
}

.desktop .group-12 {
  height: 40px;
  left: 726px;
  position: absolute;
  top: 1352px;
  width: 40px;
}

.desktop .group-13 {
  height: 40px;
  left: 726px;
  position: absolute;
  top: 1174px;
  width: 40px;
}

.desktop .ellipse-11 {
  background-color: #ef3333;
  border: 1px solid;
  border-radius: 20px;
  height: 40px;
  left: 0;
  position: absolute;
  top: 0;
  transform: rotate(-180deg);
  width: 40px;
}

.desktop .component-21 {
  left: 895px !important;
  position: absolute !important;
  top: 1135px !important;
}

.desktop .component-22 {
  height: 44px;
  left: 886px;
  position: absolute;
  top: 1292px;
  width: 146px;
}

.desktop .overlap-10 {
  height: 44px;
  position: relative;
  width: 148px;
}

.desktop .group-14 {
  height: 44px;
  left: 0;
  position: absolute;
  top: 0;
  width: 148px;
}

.desktop .overlap-group-7 {
  border-radius: 57px;
  box-shadow: 0px 2px 8px 1px #ffffff40;
  height: 44px;
  position: relative;
  width: 146px;
}

.desktop .TRY-THEO-2 {
  color: #ffffff;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 16px;
  font-weight: 400;
  left: 17px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 15px;
  white-space: nowrap;
}

.desktop .lucide-arrow-up-3 {
  height: 24px;
  left: 114px;
  position: absolute;
  top: 10px;
  width: 24px;
}

.desktop .why-choose-agent {
  color: transparent;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 64px;
  font-weight: 400;
  left: 363px;
  letter-spacing: -1px;
  line-height: 83.2px;
  position: absolute;
  top: 1774px;
  white-space: nowrap;
}

.desktop .span {
  color: #ffffff;
  letter-spacing: -0.64px;
}

.desktop .text-wrapper-25 {
  color: #ef3333;
  font-family: "Akisa-Regular", Helvetica;
  letter-spacing: -0.64px;
}

.desktop .text-wrapper-26 {
  color: #ffffff;
  font-family: "Akisa-Regular", Helvetica;
  letter-spacing: -0.64px;
}

.desktop .text-wrapper-27 {
  color: #ffffff;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 64px;
  font-weight: 400;
  left: 464px;
  letter-spacing: -1px;
  line-height: 83.2px;
  position: absolute;
  top: 2642px;
  white-space: nowrap;
}

.desktop .the-power-OF-a-money {
  color: #b0b0b0;
  font-family: "Poppins", Helvetica;
  font-size: 30px;
  font-weight: 600;
  height: 32px;
  left: 460px;
  letter-spacing: -2px;
  line-height: 31.8px;
  position: absolute;
  text-align: center;
  top: 1857px;
  white-space: nowrap;
  width: 520px;
}

.desktop .frame-18 {
  background-color: #ef3333;
  border: 1px solid;
  border-color: transparent;
  height: 423px;
  left: 3227px;
  overflow: hidden;
  position: absolute;
  top: 1334px;
  width: 300px;
}

.desktop .frame-19 {
  height: 421px;
  left: -3256px;
  position: absolute;
  top: -1335px;
  width: 298px;
}

.desktop .overlap-11 {
  height: 436px;
  left: -69px;
  position: absolute;
  top: 257px;
  width: 436px;
}

.desktop .group-15 {
  height: 436px;
  left: 0;
  position: absolute;
  top: 0;
  width: 436px;
}

.desktop .overlap-group-8 {
  height: 436px;
  position: relative;
}

.desktop .rectangle-10 {
  background: linear-gradient(
    180deg,
    rgb(255, 255, 255) 0%,
    rgb(239, 68, 68) 39.83%,
    rgb(109.7, 52.76, 239.32) 75.73%,
    rgb(115.82, 109.96, 213.48) 100%
  );
  filter: blur(12px);
  height: 308px;
  left: 64px;
  position: absolute;
  top: 64px;
  transform: rotate(45deg);
  width: 308px;
}

.desktop .rectangle-11 {
  background: linear-gradient(
    180deg,
    rgb(255, 255, 255) 0%,
    rgb(239, 68, 68) 39.83%,
    rgb(109.7, 52.76, 239.32) 75.73%,
    rgb(115.82, 109.96, 213.48) 100%
  );
  filter: blur(64px);
  height: 308px;
  left: 64px;
  position: absolute;
  top: 64px;
  transform: rotate(45deg);
  width: 308px;
}

.desktop .rectangle-12 {
  background: linear-gradient(
    180deg,
    rgb(255, 255, 255) 0%,
    rgb(239, 68, 68) 39.83%,
    rgb(109.7, 52.76, 239.32) 75.73%,
    rgb(115.82, 109.96, 213.48) 100%
  );
  filter: blur(120px);
  height: 308px;
  left: 64px;
  position: absolute;
  top: 64px;
  transform: rotate(45deg);
  width: 308px;
}

.desktop .rectangle-13 {
  background-color: #0f0f0f;
  box-shadow: inset 0px 4px 32px #ffffff40;
  height: 308px;
  left: 64px;
  position: absolute;
  top: 64px;
  transform: rotate(45deg);
  width: 308px;
}

.desktop .frame-20 {
  border-radius: 16px;
  height: 3px;
  left: 2713px;
  position: absolute;
  top: 3365px;
  width: 1328px;
}

.desktop .from-to-millions {
  color: #ffffff;
  font-family: "Poppins", Helvetica;
  font-size: 42px;
  font-weight: 500;
  height: 118px;
  left: 550px;
  letter-spacing: -2px;
  line-height: 44.5px;
  position: absolute;
  text-align: center;
  top: 425px;
  width: 711px;
}

.desktop .in-the-fiat-world {
  color: transparent;
  font-family: "Poppins", Helvetica;
  font-size: 29px;
  font-weight: 400;
  height: 213px;
  left: 17px;
  letter-spacing: -2px;
  line-height: 30.7px;
  position: absolute;
  text-align: center;
  top: -475px;
  width: 1311px;
}

.desktop .text-wrapper-28 {
  color: #ffffff;
  font-weight: 500;
  letter-spacing: -0.58px;
}

.desktop .text-wrapper-29 {
  color: #b0b0b0;
  font-weight: 500;
  letter-spacing: -0.58px;
}

.desktop .text-wrapper-30 {
  color: #d2ff3a;
  font-family: "Akisa-Regular", Helvetica;
  letter-spacing: -0.58px;
}

.desktop .text-wrapper-31 {
  color: #d2ff3a;
  font-weight: 500;
  letter-spacing: -0.58px;
}

.desktop .group-16 {
  height: 56px;
  left: 3271px;
  position: absolute;
  top: 8457px;
  width: 212px;
}

.desktop .ASK-THEO-wrapper {
  -webkit-backdrop-filter: blur(50px) brightness(100%);
  backdrop-filter: blur(50px) brightness(100%);
  background-color: #d2ff3a;
  border-radius: 40px;
  height: 56px;
  left: 0;
  position: absolute;
  top: 0;
  width: 145px;
}

.desktop .ASK-THEO {
  color: #1f1f1f;
  font-family: "Poppins", Helvetica;
  font-size: 16px;
  font-weight: 600;
  left: 32px;
  letter-spacing: 0.48px;
  line-height: normal;
  position: absolute;
  top: 16px;
}

.desktop .vector-wrapper {
  background-color: #ef3333;
  border-radius: 28px;
  height: 56px;
  left: 156px;
  position: absolute;
  top: 0;
  width: 56px;
}

.desktop .vector {
  height: 32px;
  left: 3px;
  position: absolute;
  top: 8px;
  width: 24px;
}

.desktop .overlap-12 {
  height: 541px;
  left: 2706px;
  position: absolute;
  top: 4656px;
  width: 1330px;
}

.desktop .frame-21 {
  background-color: #ef3333;
  border-radius: 16px;
  box-shadow: 0px 4px 43px #feb5b5;
  height: 373px;
  left: 548px;
  position: absolute;
  top: 45px;
  width: 674px;
}

.desktop .map {
  height: 541px;
  left: 368px;
  object-fit: cover;
  position: absolute;
  top: 0;
  width: 962px;
}

.desktop .frame-22 {
  height: 117px;
  left: 0;
  position: absolute;
  top: 218px;
  width: 574px;
}

.desktop .accessible-to {
  color: #f5f5f5;
  font-family: "Poppins", Helvetica;
  font-size: 64px;
  font-weight: 600;
  height: 45px;
  left: 0;
  letter-spacing: -2px;
  line-height: 57.6px;
  position: absolute;
  text-shadow: 0px 2px 1px #00000026;
  top: -1px;
  white-space: nowrap;
}

.desktop .text-wrapper-32 {
  color: #f5f5f5;
  font-family: "Poppins", Helvetica;
  font-size: 64px;
  font-weight: 600;
  height: 45px;
  left: 0;
  letter-spacing: -2px;
  line-height: 57.6px;
  opacity: 0.7;
  position: absolute;
  top: 71px;
  white-space: nowrap;
}

.desktop .overlap-13 {
  height: 656px;
  left: 117px;
  position: absolute;
  top: 1975px;
  width: 1323px;
}

.desktop .overlap-14 {
  height: 656px;
  left: 0;
  position: absolute;
  top: 0;
  width: 1323px;
}

.desktop .group-17 {
  height: 470px;
  left: 999px;
  position: absolute;
  top: 186px;
  width: 324px;
}

.desktop .frame-23 {
  background-color: #ef3333;
  border-radius: 16px;
  box-shadow: 0px 4px 43px #feb5b5;
  height: 373px;
  left: 482px;
  position: absolute;
  top: 39px;
  width: 674px;
}

.desktop .map-2 {
  height: 541px;
  left: 347px;
  object-fit: cover;
  position: absolute;
  top: 0;
  width: 962px;
}

.desktop .accessible-to-2 {
  color: transparent;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 63px;
  font-weight: 400;
  height: 101px;
  left: 0;
  letter-spacing: -2px;
  line-height: 56.7px;
  position: absolute;
  text-shadow: 0px 2px 1px #00000026;
  top: 197px;
  width: 396px;
}

.desktop .text-wrapper-33 {
  color: #ffffff;
  letter-spacing: -1.26px;
}

.desktop .text-wrapper-34 {
  color: #b0b0b0;
  letter-spacing: -1.26px;
}

.desktop .from-to-millions-2 {
  color: transparent;
  font-family: "Poppins", Helvetica;
  font-size: 30px;
  font-weight: 600;
  height: 118px;
  left: 456px;
  letter-spacing: -2px;
  line-height: 31.8px;
  position: absolute;
  text-align: center;
  top: 461px;
  width: 711px;
}

.desktop .text-wrapper-35 {
  color: #ffffff;
  letter-spacing: -0.6px;
}

.desktop .text-wrapper-36 {
  color: #b0b0b0;
  letter-spacing: -0.6px;
}

.desktop .component-23 {
  left: 0 !important;
  position: absolute !important;
  top: 329px !important;
}

.desktop .why-choose-agent-2 {
  color: transparent;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 64px;
  font-weight: 400;
  height: 45px;
  left: 2930px;
  letter-spacing: -2px;
  line-height: 57.6px;
  position: absolute;
  text-align: center;
  text-shadow: 0px 2px 1px #00000026;
  top: 4500px;
  width: 812px;
}

.desktop .text-wrapper-37 {
  color: #ffffff;
  letter-spacing: -1.28px;
}

.desktop .text-wrapper-38 {
  color: #d2ff3a;
  letter-spacing: -1.28px;
}

.desktop .text-wrapper-39 {
  color: #d2ff3a;
  font-family: "Akisa-Regular", Helvetica;
  letter-spacing: -1.28px;
}

.desktop .the-power-of-a-money {
  color: #ffffff;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 40px;
  font-weight: 400;
  height: 28px;
  left: 3013px;
  letter-spacing: -2px;
  line-height: 36px;
  position: absolute;
  text-align: center;
  text-shadow: 0px 2px 1px #00000026;
  top: 4584px;
  white-space: nowrap;
}

.desktop .AI-drive-precision {
  color: #ffffff;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 50px;
  font-weight: 400;
  height: 35px;
  left: -2005px;
  letter-spacing: -2px;
  line-height: 45px;
  position: absolute;
  text-align: center;
  text-shadow: 0px 2px 1px #00000026;
  top: 3067px;
  width: 358px;
}

.desktop .overlap-15 {
  height: 624px;
  left: 103px;
  position: absolute;
  top: 3462px;
  width: 1277px;
}

.desktop .overlap-16 {
  height: 624px;
  left: 540px;
  position: absolute;
  top: 0;
  width: 737px;
}

.desktop .cvuvmawu {
  height: 624px;
  left: 113px;
  position: absolute;
  top: 0;
  width: 624px;
}

.desktop .component-78-wrapper {
  height: 44px;
  left: 0;
  position: absolute;
  top: 51px;
  width: 146px;
}

.desktop .component-24 {
  width: unset !important;
}

.desktop .frame-24 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 58px;
  left: 0;
  position: absolute;
  top: 285px;
  width: 590px;
}

.desktop .secure-private {
  align-self: stretch;
  color: #ffffff;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 63px;
  font-weight: 400;
  height: 32px;
  letter-spacing: -2px;
  line-height: 56.7px;
  margin-top: -1px;
  position: relative;
  text-shadow: 0px 2px 1px #00000026;
  white-space: nowrap;
}

.desktop .no-private-key {
  align-self: stretch;
  color: transparent;
  font-family: "Poppins", Helvetica;
  font-size: 37px;
  font-weight: 500;
  height: 51px;
  letter-spacing: -2px;
  line-height: 42.5px;
  position: relative;
  text-shadow: 0px 2px 1px #00000026;
  white-space: nowrap;
}

.desktop .text-wrapper-40 {
  color: #ffffff;
  letter-spacing: -0.74px;
}

.desktop .text-wrapper-41 {
  color: #b0b0b0;
  letter-spacing: -0.74px;
}

.desktop .unlike-human {
  color: transparent;
  font-family: "Poppins", Helvetica;
  font-size: 37px;
  font-weight: 500;
  height: 69px;
  left: 175px;
  letter-spacing: -2px;
  line-height: 42.5px;
  position: absolute;
  text-align: center;
  text-shadow: 0px 2px 1px #00000026;
  top: 4923px;
  width: 1089px;
}

.desktop .text-wrapper-42 {
  color: #ffffff;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 16px;
  font-weight: 400;
  left: 118px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 6634px;
  white-space: nowrap;
}

.desktop .text-wrapper-43 {
  color: #ffffff;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 16px;
  font-weight: 400;
  left: 207px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 6634px;
  white-space: nowrap;
}

.desktop .text-wrapper-44 {
  color: #ffffff;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 16px;
  font-weight: 400;
  left: 285px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 6634px;
  white-space: nowrap;
}

.desktop .text-wrapper-45 {
  color: #ffffff;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 16px;
  font-weight: 400;
  left: 412px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 6634px;
  white-space: nowrap;
}

.desktop .text-wrapper-46 {
  color: #ffffffb2;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 16px;
  font-weight: 400;
  left: 1164px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 6634px;
  white-space: nowrap;
}

.desktop .overlap-17 {
  height: 1123px;
  left: 0;
  position: absolute;
  top: 0;
  width: 1889px;
}

.desktop .frame-25 {
  height: 347px;
  left: 126px;
  position: absolute;
  top: 776px;
  width: 1188px;
}

.desktop .theo-red-3 {
  height: 93px;
  left: 688px;
  object-fit: cover;
  position: absolute;
  top: 1162px;
  width: 93px;
}

.desktop .introducing-agent {
  color: transparent;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 64px;
  font-weight: 400;
  height: 45px;
  left: 322px;
  letter-spacing: -2px;
  line-height: 57.6px;
  position: absolute;
  text-align: center;
  text-shadow: 0px 2px 1px #00000026;
  top: 1342px;
  width: 812px;
}

.desktop .text-wrapper-47 {
  color: #ef3333;
  font-family: "Akisa-Regular", Helvetica;
  letter-spacing: -1.28px;
}

.desktop .in-the-fiat-world-2 {
  color: #b0b0b0;
  font-family: "Poppins", Helvetica;
  font-size: 29px;
  font-weight: 500;
  height: 286px;
  left: 87px;
  letter-spacing: -2px;
  line-height: 30.7px;
  position: absolute;
  text-align: center;
  top: 1436px;
  width: 1311px;
}

.desktop .frame-wrapper {
  height: 45px;
  left: 521px;
  position: absolute;
  top: 4144px;
  width: 496px;
}

.desktop .frame-26 {
  height: 45px;
  position: relative;
}

.desktop .text-wrapper-48 {
  color: #f5f5f5;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 64px;
  font-weight: 400;
  height: 45px;
  left: 83px;
  letter-spacing: -2px;
  line-height: 57.6px;
  position: absolute;
  text-align: center;
  text-shadow: 0px 2px 1px #00000026;
  top: -1px;
  white-space: nowrap;
}

.desktop .x {
  height: 48px;
  left: 1283px;
  position: absolute;
  top: 6616px;
  width: 31px;
}

.desktop .linked-in {
  height: 48px;
  left: 1323px;
  position: absolute;
  top: 6616px;
  width: 31px;
}

.desktop .discord-new {
  height: 48px;
  left: 1363px;
  position: absolute;
  top: 6616px;
  width: 31px;
}
</style>