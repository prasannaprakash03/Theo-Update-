import PropTypes from "prop-types";
import React from "react";
import styled from "styled-components";

const StyledPropertyWrapper = styled.div`
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 16px;
  justify-content: center;
  position: relative;
  width: 180px;

  & .title {
    align-items: center;
    align-self: stretch;
    display: flex;
    flex: 0 0 auto;
    gap: 6px;
    position: relative;
    width: 100%;
  }

  & .ETH {
    height: 24px;
    position: relative;
    width: 24px;
  }

  & .ETH-USD {
    color: #ffffff;
    font-family: "Outfit", Helvetica;
    font-size: 18px;
    font-weight: 500;
    letter-spacing: -0.72px;
    line-height: 25.2px;
    margin-top: -1.00px;
    position: relative;
  }

  & .element-wrapper {
    align-items: flex-start;
    background-color: #ffffff1a;
    border-radius: 32px;
    display: inline-flex;
    flex: 0 0 auto;
    gap: 8px;
    padding: 4px 8px;
    position: relative;
  }

  & .element-4 {
    color: #ffffff;
    font-family: "DM Sans", Helvetica;
    font-size: 14px;
    font-weight: 400;
    letter-spacing: 1.40px;
    line-height: 19.6px;
    margin-top: -1.00px;
    opacity: 0.7;
    position: relative;
    white-space: nowrap;
    width: fit-content;
  }

  & .two {
    white-space: nowrap;
    width: fit-content;
  }

  & .six {
    width: 150px;
  }

  & .four {
    width: 150px;
  }

  & .five {
    width: 150px;
  }

  & .one {
    white-space: nowrap;
    width: fit-content;
  }

  & .three {
    white-space: nowrap;
    width: fit-content;
  }
`;

export const PropertyWrapper = ({
  property1,
  className,
  titleClassName,
  ETHClassName,
  tether = "/img/tether.svg",
  divClassName,
  text = "USDT/USD",
  frameClassName,
  divClassNameOverride,
  uniswap = "/img/uniswap.svg",
  text1 = "UNI/USD",
  text2 = "45%",
  LUNA = "/img/luna.svg",
  ETH = "/img/eth.svg",
  doge = "/img/doge.svg",
  solana = "/img/solana.svg",
}) => {
  return (
    <StyledPropertyWrapper className={className}>
      <div className={`title ${titleClassName}`}>
        <img
          className={`ETH ${ETHClassName}`}
          alt="Eth"
          src={
            property1 === "five"
              ? solana
              : property1 === "four"
                ? LUNA
                : property1 === "three"
                  ? tether
                  : property1 === "two"
                    ? uniswap
                    : property1 === "one"
                      ? doge
                      : ETH
          }
        />

        <div className={`ETH-USD ${property1} ${divClassName}`}>
          {property1 === "six" && <>ETH/USD</>}

          {property1 === "five" && <>SOl/USD</>}

          {property1 === "four" && <>LUNA/USD</>}

          {property1 === "three" && <>{text}</>}

          {property1 === "two" && <>{text1}</>}

          {property1 === "one" && <>DOGE/USD</>}
        </div>
      </div>

      <div className={`element-wrapper ${frameClassName}`}>
        <div className={`element-4 ${divClassNameOverride}`}>
          {property1 === "six" && <>75%</>}

          {property1 === "five" && <>25%</>}

          {property1 === "four" && <>15%</>}

          {property1 === "three" && <>68%</>}

          {["one", "two"].includes(property1) && <>{text2}</>}
        </div>
      </div>
    </StyledPropertyWrapper>
  );
};

PropertyWrapper.propTypes = {
  property1: PropTypes.oneOf(["two", "three", "four", "one", "five", "six"]),
  tether: PropTypes.string,
  text: PropTypes.string,
  uniswap: PropTypes.string,
  text1: PropTypes.string,
  text2: PropTypes.string,
  LUNA: PropTypes.string,
  ETH: PropTypes.string,
  doge: PropTypes.string,
  solana: PropTypes.string,
};
