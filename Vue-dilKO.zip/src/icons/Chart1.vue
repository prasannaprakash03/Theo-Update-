<template>
  <svg
    :class="['chart-1', className]"
    fill="none"
    height="70"
    viewBox="0 0 114 70"
    width="114"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      class="path-2"
      d="M1.43335 61.8132L3.75263 64.0311C6.0719 66.2491 10.7105 70.685 15.349 67.8005C19.9876 64.9161 24.6261 54.7113 29.2647 52.6008C33.9032 50.4903 38.5418 56.4741 43.1803 58.968C47.8189 61.4619 52.4574 60.4659 57.096 60.0063C61.7346 59.5467 66.3731 59.6235 71.0117 59.8558C75.6502 60.0881 80.2888 60.4759 84.9273 61.6714C89.5659 62.8668 94.2044 64.8698 98.843 65.4902C103.482 66.1107 108.12 65.3485 110.439 64.9674L112.759 64.5863"
      stroke="#37CBB0"
      stroke-linecap="round"
      stroke-width="2.40964"
    />
  </svg>
</template>

<script>
export default {
  name: "Chart1",
  props: {
    className: {
      type: String,
      default: "",
    },
  },
};
</script>

<style>
</style>