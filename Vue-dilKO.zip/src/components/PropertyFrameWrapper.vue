<template>
  <div :class="['property-frame-wrapper', className]">
    <div class="overlap-5">
      <div class="group-8">
        <div class="TRY-THEO-wrapper">
          <div class="TRY-THEO">{{ text }}</div>
        </div>
      </div>
      <img
        class="lucide-arrow-up"
        alt="Lucide arrow up"
        src="/img/lucide-arrow-up-2.svg"
      />
    </div>
  </div>
</template>

<script>
export default {
  name: "PropertyFrameWrapper",
  props: {
    property1: {
      type: String,
      validator: function (value) {
        return ["frame-2147223996", "frame-2147223995"].indexOf(value) !== -1;
      },
    },
    text: {
      type: String,
      default: "TRY THEO",
    },
    className: {
      type: String,
      default: "",
    },
  },
};
</script>

<style>
.property-frame-wrapper {
  height: 44px;
  width: 146px;
}

.property-frame-wrapper .overlap-5 {
  height: 44px;
  position: relative;
  width: 148px;
}

.property-frame-wrapper .group-8 {
  height: 44px;
  left: 0;
  position: absolute;
  top: 0;
  width: 148px;
}

.property-frame-wrapper .TRY-THEO-wrapper {
  border-radius: 57px;
  box-shadow: 0px 2px 8px 1px #ffffff40;
  height: 44px;
  position: relative;
  width: 146px;
}

.property-frame-wrapper .TRY-THEO {
  color: #ffffff;
  font-family: "Gendy-Regular", Helvetica;
  font-size: 16px;
  font-weight: 400;
  left: 17px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  top: 15px;
  white-space: nowrap;
}

.property-frame-wrapper .lucide-arrow-up {
  height: 24px;
  left: 104px;
  position: absolute;
  top: 10px;
  width: 24px;
}
</style>