import PropTypes from "prop-types";
import React from "react";
import styled from "styled-components";

const StyledPropertyFrameWrapper = styled.div`
  height: 44px;
  width: 146px;

  & .overlap-5 {
    height: 44px;
    position: relative;
    width: 148px;
  }

  & .group-8 {
    height: 44px;
    left: 0;
    position: absolute;
    top: 0;
    width: 148px;
  }

  & .TRY-THEO-wrapper {
    border-radius: 57px;
    box-shadow: 0px 2px 8px 1px #ffffff40;
    height: 44px;
    position: relative;
    width: 146px;
  }

  & .TRY-THEO {
    color: #ffffff;
    font-family: "Gendy-Regular", Helvetica;
    font-size: 16px;
    font-weight: 400;
    left: 17px;
    letter-spacing: 0;
    line-height: normal;
    position: absolute;
    top: 15px;
    white-space: nowrap;
  }

  & .lucide-arrow-up {
    height: 24px;
    left: 104px;
    position: absolute;
    top: 10px;
    width: 24px;
  }
`;

export const PropertyFrameWrapper = ({
  property1,
  className,
  text = "TRY THEO",
}) => {
  return (
    <StyledPropertyFrameWrapper className={className}>
      <div className="overlap-5">
        <div className="group-8">
          <div className="TRY-THEO-wrapper">
            <div className="TRY-THEO">{text}</div>
          </div>
        </div>

        <img
          className="lucide-arrow-up"
          alt="Lucide arrow up"
          src="/img/lucide-arrow-up-2.svg"
        />
      </div>
    </StyledPropertyFrameWrapper>
  );
};

PropertyFrameWrapper.propTypes = {
  property1: PropTypes.oneOf(["frame-2147223996", "frame-2147223995"]),
  text: PropTypes.string,
};
